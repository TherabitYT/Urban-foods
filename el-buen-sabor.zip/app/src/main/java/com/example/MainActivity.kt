package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.OrderStatus
import com.example.ui.AppTab
import com.example.ui.RestaurantViewModel
import com.example.ui.components.AdminAuthDialog
import com.example.ui.components.CartBottomSheet
import com.example.ui.components.DeliveryAddressDialog
import com.example.ui.components.DriverChatDialog
import com.example.ui.components.FoodDetailBottomSheet
import com.example.ui.components.UserProfileDialog
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.screens.OrderHistoryScreen
import com.example.ui.screens.TrackingScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        RestaurantApp()
      }
    }
  }
}

@Composable
fun RestaurantApp(
  viewModel: RestaurantViewModel = viewModel()
) {
  val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
  val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val selectedDish by viewModel.selectedDishForCustomization.collectAsStateWithLifecycle()
  val allDishes by viewModel.allDishes.collectAsStateWithLifecycle()

  val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
  val isCartOpen by viewModel.isCartOpen.collectAsStateWithLifecycle()

  val savedAddresses by viewModel.savedAddresses.collectAsStateWithLifecycle()
  val selectedAddress by viewModel.selectedAddress.collectAsStateWithLifecycle()
  val isAddressDialogOpen by viewModel.isAddressDialogOpen.collectAsStateWithLifecycle()

  val activeOrder by viewModel.activeOrder.collectAsStateWithLifecycle()
  val allOrders by viewModel.allOrders.collectAsStateWithLifecycle()

  val isChatDialogOpen by viewModel.isChatDialogOpen.collectAsStateWithLifecycle()
  val chatMessages by viewModel.driverChatMessages.collectAsStateWithLifecycle()

  val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
  val isProfileDialogOpen by viewModel.isProfileDialogOpen.collectAsStateWithLifecycle()

  val isAdminAuthenticated by viewModel.isAdminAuthenticated.collectAsStateWithLifecycle()
  val isAdminDialogOpen by viewModel.isAdminDialogOpen.collectAsStateWithLifecycle()
  val adminPasswordError by viewModel.adminPasswordError.collectAsStateWithLifecycle()
  val notificationHistory by viewModel.notificationHistory.collectAsStateWithLifecycle()

  val effectiveAddress = selectedAddress ?: savedAddresses.firstOrNull { it.isDefault } ?: savedAddresses.firstOrNull()

  // If Admin is logged in, show the Admin Dashboard Screen
  if (isAdminAuthenticated) {
    AdminDashboardScreen(
      orders = allOrders,
      allDishes = allDishes,
      notifications = notificationHistory,
      onUpdateOrderStatus = { orderId, newStatus ->
        viewModel.adminUpdateOrderStatus(orderId, newStatus)
      },
      onDeleteOrder = { orderId ->
        viewModel.adminDeleteOrder(orderId)
      },
      onAddNewDish = { name, cat, desc, price, prepTime, ingredients, badge ->
        viewModel.adminAddNewMenuItem(name, cat, desc, price, prepTime, ingredients, badge)
      },
      onToggleDishAvailability = { dishId, isAvailable ->
        viewModel.adminToggleDishAvailability(dishId, isAvailable)
      },
      onDeleteDish = { dishId ->
        viewModel.adminDeleteCustomDish(dishId)
      },
      onBroadcastPromo = { title, msg ->
        viewModel.adminBroadcastPromotion(title, msg)
      },
      onSaveOrUpdateDish = { updatedDish ->
        viewModel.adminSaveOrUpdateMenuItem(updatedDish)
      },
      onExitAdmin = {
        viewModel.exitAdminMode()
      }
    )
    return
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
          .windowInsetsPadding(WindowInsets.navigationBars)
          .testTag("bottom_nav_bar")
      ) {
        // Tab 1: Menú
        NavigationBarItem(
          selected = currentTab == AppTab.MENU,
          onClick = { viewModel.setTab(AppTab.MENU) },
          icon = {
            Icon(
              imageVector = Icons.Default.RestaurantMenu,
              contentDescription = "Menú"
            )
          },
          label = {
            Text(
              text = "Menú",
              fontWeight = if (currentTab == AppTab.MENU) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            selectedIconColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.testTag("nav_item_menu")
        )

        // Tab 2: Seguimiento en tiempo real (En Camino)
        val hasActiveDelivery = activeOrder != null && activeOrder?.status != OrderStatus.ENTREGADO
        NavigationBarItem(
          selected = currentTab == AppTab.TRACKING,
          onClick = { viewModel.setTab(AppTab.TRACKING) },
          icon = {
            BadgedBox(
              badge = {
                if (hasActiveDelivery) {
                  Badge(containerColor = MaterialTheme.colorScheme.primary) {
                    Text("1")
                  }
                }
              }
            ) {
              Icon(
                imageVector = Icons.Default.TwoWheeler,
                contentDescription = "En Camino"
              )
            }
          },
          label = {
            Text(
              text = "En Camino",
              fontWeight = if (currentTab == AppTab.TRACKING) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            selectedIconColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.testTag("nav_item_tracking")
        )

        // Tab 3: Historial
        NavigationBarItem(
          selected = currentTab == AppTab.HISTORY,
          onClick = { viewModel.setTab(AppTab.HISTORY) },
          icon = {
            Icon(
              imageVector = Icons.Default.History,
              contentDescription = "Historial"
            )
          },
          label = {
            Text(
              text = "Historial",
              fontWeight = if (currentTab == AppTab.HISTORY) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
            selectedIconColor = MaterialTheme.colorScheme.primary
          ),
          modifier = Modifier.testTag("nav_item_history")
        )
      }
    }
  ) { innerPadding ->
    when (currentTab) {
      AppTab.MENU -> {
        MenuScreen(
          items = allDishes,
          selectedCategory = selectedCategory,
          searchQuery = searchQuery,
          cartItems = cartItems,
          currentAddress = effectiveAddress,
          userProfile = userProfile,
          onSelectCategory = { viewModel.setCategory(it) },
          onSearchQueryChange = { viewModel.setSearchQuery(it) },
          onSelectDish = { viewModel.openDishDetail(it) },
          onOpenAddressDialog = { viewModel.openAddressDialog() },
          onOpenCart = { viewModel.openCart() },
          onOpenProfile = { viewModel.openProfileDialog() },
          onOpenAdminAuth = { viewModel.openAdminDialog() },
          modifier = Modifier.padding(innerPadding)
        )
      }

      AppTab.TRACKING -> {
        TrackingScreen(
          order = activeOrder,
          onAdvanceSimulation = { viewModel.advanceSimulationStepManually() },
          onOpenChat = { viewModel.openChatDialog() },
          onGoToMenu = { viewModel.setTab(AppTab.MENU) },
          modifier = Modifier.padding(innerPadding)
        )
      }

      AppTab.HISTORY -> {
        OrderHistoryScreen(
          orders = allOrders,
          onReorder = { order, directCheckout ->
            viewModel.reorderPastOrder(order, directCheckout)
          },
          onGoToMenu = { viewModel.setTab(AppTab.MENU) },
          modifier = Modifier.padding(innerPadding)
        )
      }
    }
  }

  // Dish Customization Bottom Sheet
  selectedDish?.let { item ->
    FoodDetailBottomSheet(
      item = item,
      onAddToCart = { dish, qty, spice, side, extras, notes ->
        viewModel.addToCart(dish, qty, spice, side, extras, notes)
      },
      onDismiss = { viewModel.closeDishDetail() }
    )
  }

  // Cart Bottom Sheet
  if (isCartOpen) {
    CartBottomSheet(
      items = cartItems,
      currentAddress = effectiveAddress,
      onUpdateQuantity = { id, delta -> viewModel.updateCartQuantity(id, delta) },
      onRemoveItem = { id -> viewModel.removeCartItem(id) },
      onOpenAddressDialog = { viewModel.openAddressDialog() },
      onConfirmCheckout = { paymentMethod ->
        viewModel.checkoutOrder(paymentMethod)
      },
      onDismiss = { viewModel.closeCart() }
    )
  }

  // Delivery Address Dialog
  if (isAddressDialogOpen) {
    DeliveryAddressDialog(
      savedAddresses = savedAddresses,
      currentAddress = effectiveAddress,
      onSelectSavedAddress = { viewModel.selectAddress(it) },
      onSaveNewAddress = { label, street, num, neigh, ref, phone, isDef, lat, lng ->
        viewModel.saveNewAddress(label, street, num, neigh, ref, phone, isDef, lat, lng)
      },
      onDismiss = { viewModel.closeAddressDialog() }
    )
  }

  // Driver Chat Dialog
  if (isChatDialogOpen) {
    DriverChatDialog(
      driverName = activeOrder?.driverName ?: "Carlos Mendoza",
      driverPlate = activeOrder?.driverPlate ?: "MOTO-782",
      driverPhone = activeOrder?.driverPhone ?: "+57 312 884 9201",
      messages = chatMessages,
      onSendMessage = { text -> viewModel.sendCustomerMessage(text) },
      onDismiss = { viewModel.closeChatDialog() }
    )
  }

  // User Profile & Google Sign-In Dialog
  if (isProfileDialogOpen) {
    UserProfileDialog(
      userProfile = userProfile,
      onSignInWithGoogle = { viewModel.signInWithGoogle() },
      onSignOut = { viewModel.signOutGoogle() },
      onOpenAdminAccess = {
        viewModel.closeProfileDialog()
        viewModel.openAdminDialog()
      },
      onDismiss = { viewModel.closeProfileDialog() }
    )
  }

  // Admin Master Key Access Dialog
  if (isAdminDialogOpen) {
    AdminAuthDialog(
      errorMessage = adminPasswordError,
      onVerifyPassword = { inputKey ->
        viewModel.verifyAndLoginAdmin(inputKey)
      },
      onDismiss = { viewModel.closeAdminDialog() }
    )
  }
}
