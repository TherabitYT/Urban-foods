package com.example.model

import androidx.annotation.DrawableRes
import com.example.R

enum class FoodCategory(val displayName: String, val iconText: String) {
  TODOS("Todos", "🔥"),
  ARROZ_CHINO("Arroz Chino", "🍚"),
  TACOS("Tacos", "🌮"),
  HOT_DOGS("Perros Calientes", "🌭"),
  HAMBURGUESAS("Hamburguesas", "🍔"),
  BEBIDAS("Bebidas y Extras", "🥤")
}

data class ExtraOption(
  val id: String,
  val name: String,
  val price: Double
)

data class SpiceLevel(
  val id: String,
  val name: String,
  val description: String,
  val price: Double = 0.0,
  val icon: String = "🌶️"
)

data class SideOption(
  val id: String,
  val name: String,
  val price: Double
)

data class MenuItem(
  val id: String,
  val name: String,
  val category: FoodCategory,
  val description: String,
  val price: Double,
  @DrawableRes val imageRes: Int = R.drawable.img_burger,
  val customImageUrl: String? = null,
  val badge: String? = null,
  val preparationTime: String = "15-20 min",
  val ingredients: List<String> = emptyList(),
  val availableExtras: List<ExtraOption> = emptyList(),
  val availableSides: List<SideOption> = emptyList(),
  val availableSpiceLevels: List<SpiceLevel> = emptyList(),
  val isAvailable: Boolean = true
)

data class CartItem(
  val id: String,
  val menuItem: MenuItem,
  val quantity: Int,
  val selectedSpiceLevel: SpiceLevel? = null,
  val selectedSide: SideOption? = null,
  val selectedExtras: List<ExtraOption> = emptyList(),
  val specialInstructions: String = ""
) {
  val unitPrice: Double
    get() = menuItem.price +
      (selectedSpiceLevel?.price ?: 0.0) +
      (selectedSide?.price ?: 0.0) +
      selectedExtras.sumOf { it.price }

  val totalPrice: Double
    get() = unitPrice * quantity
}

