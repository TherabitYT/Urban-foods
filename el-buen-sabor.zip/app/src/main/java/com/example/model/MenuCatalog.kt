package com.example.model

import com.example.R

object MenuCatalog {

  val standardSpiceLevels = listOf(
    SpiceLevel("sp_none", "Sin Picante / Clásico", "El sabor equilibrado de la casa", 0.0, "🌿"),
    SpiceLevel("sp_mild", "Picante Suave", "Toque sutil de jalapeño y hierbas", 0.0, "🌶️"),
    SpiceLevel("sp_medium", "Picante Medio", "Chipotle ahumado y ají criollo", 0.0, "🔥"),
    SpiceLevel("sp_hot", "Picante Bravo", "Habanero artesanal y sriracha (+ $0.50)", 0.50, "💥"),
    SpiceLevel("sp_dragon", "Fuego Dragón", "Nivel extremo con ají chombo (+ $0.75)", 0.75, "☠️")
  )

  val standardSides = listOf(
    SideOption("sd_none", "Sin Guarnición", 0.0),
    SideOption("sd_papas", "Papas Rústicas al Romero", 2.20),
    SideOption("sd_aros", "Aros de Cebolla Crocantes", 2.50),
    SideOption("sd_platano", "Plátano Maduro con Queso Costeño", 1.80),
    SideOption("sd_coleslaw", "Ensalada Coleslaw Fresca", 1.50),
    SideOption("sd_yuca", "Yuca Frita con Tártara", 2.00)
  )

  private val commonExtras = listOf(
    ExtraOption("ext_queso", "Queso Fundido Extra", 1.25),
    ExtraOption("ext_bacon", "Tocineta Crujiente", 1.50),
    ExtraOption("ext_guac", "Guacamole Artesanal", 1.75),
    ExtraOption("ext_salsa", "Salsa Especial de la Casa", 0.75),
    ExtraOption("ext_papas", "Porción de Papitas Rústicas", 2.00)
  )

  val allItems: List<MenuItem> = listOf(
    // 1. ARROZ CHINO
    MenuItem(
      id = "ac_1",
      name = "Arroz Chino Especial Tres Carnes",
      category = FoodCategory.ARROZ_CHINO,
      description = "Pollo tierno, cerdo ahumado artesanal y camarones salteados al wok a fuego vivo, cebollín fresco, tortilla de huevo y salsa de soya imperial.",
      price = 8.50,
      imageRes = R.drawable.img_arroz_chino,
      badge = "Más Vendido 🔥",
      preparationTime = "15-20 min",
      ingredients = listOf("Pollo", "Cerdo Ahumado", "Camarones", "Cebollín", "Brotes de soya", "Huevo"),
      availableExtras = listOf(
        ExtraOption("ac_camaron", "Extra Camarones Jumbo (4 uds)", 2.50),
        ExtraOption("ac_lumpias", "Rollitos Primavera (2 uds)", 1.75),
        ExtraOption("ac_picante", "Salsa Agridulce y Picante Sriracha", 0.60),
        ExtraOption("ac_huevo", "Tortilla de Huevo Extra", 1.00)
      ),
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "ac_2",
      name = "Arroz Chaufa de Pollo y Vegetales",
      category = FoodCategory.ARROZ_CHINO,
      description = "Tradicional arroz salteado en wok al estilo chifa con dados de pechuga jugosa, pimientos rojos, jengibre fresco, ajonjolí y cebollín verde.",
      price = 7.00,
      imageRes = R.drawable.img_arroz_chino,
      badge = "Favorito",
      preparationTime = "12-18 min",
      ingredients = listOf("Pechuga de pollo", "Jengibre", "Pimiento", "Sillao", "Cebollín"),
      availableExtras = commonExtras,
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "ac_3",
      name = "Arroz Frito Especial Camarón & Res",
      category = FoodCategory.ARROZ_CHINO,
      description = "Fusión de carne tierna de res salteada con camarones frescos, plátano maduro en cubos dorados, tocineta y cebolla caramelizada.",
      price = 9.20,
      imageRes = R.drawable.img_arroz_chino,
      badge = "Recomendado",
      preparationTime = "15-20 min",
      ingredients = listOf("Res marinada", "Camarón", "Plátano maduro", "Tocineta", "Soya oscura"),
      availableExtras = commonExtras,
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),

    // 2. TACOS
    MenuItem(
      id = "tc_1",
      name = "Tacos al Pastor con Piña Asada",
      category = FoodCategory.TACOS,
      description = "Orden de 3 tacos en tortilla de maíz suave, carne de cerdo adobada en achiote tradicional, piña caramelizada al carbón, cebolla, cilantro y limones.",
      price = 6.75,
      imageRes = R.drawable.img_tacos,
      badge = "Estrella 🌮",
      preparationTime = "10-15 min",
      ingredients = listOf("Carne al Pastor", "Tortilla de maíz", "Piña asada", "Cebolla", "Cilantro fresco"),
      availableExtras = listOf(
        ExtraOption("tc_guac", "Guacamole Cremoso Artesanal", 1.50),
        ExtraOption("tc_queso", "Costra de Queso Oaxaca", 1.25),
        ExtraOption("tc_extra_taco", "Taco Adicional al Pastor", 2.25)
      ),
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "tc_2",
      name = "Tacos de Birria de Res con Consomé",
      category = FoodCategory.TACOS,
      description = "Tacos dorados a la plancha con carne de res deshebrada super tierna, queso derretido en costra crocante y tazón de caldo aromático para sopear.",
      price = 8.90,
      imageRes = R.drawable.img_tacos,
      badge = "Especial del Chef",
      preparationTime = "15-20 min",
      ingredients = listOf("Birria de res suave", "Queso derretido", "Consomé especiado", "Cilantro", "Cebolla morada"),
      availableExtras = listOf(
        ExtraOption("tc_birria_consome", "Consomé Extra con Carne", 2.00),
        ExtraOption("tc_guac", "Guacamole Cremoso Artesanal", 1.50),
        ExtraOption("tc_queso", "Extra Queso Oaxaca Fundido", 1.25)
      ),
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "tc_3",
      name = "Tacos de Carnitas Estilo Michoacán",
      category = FoodCategory.TACOS,
      description = "Tres tacos con carnitas jugosas confitadas lentamente a fuego bajo, acompañadas de chicharrón crujiente, cebolla encurtida y salsa taquera.",
      price = 7.25,
      imageRes = R.drawable.img_tacos,
      badge = null,
      preparationTime = "10-15 min",
      ingredients = listOf("Carnitas de cerdo", "Chicharrón molido", "Cebolla morada", "Limón"),
      availableExtras = commonExtras,
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),

    // 3. PERROS CALIENTES
    MenuItem(
      id = "hd_1",
      name = "Perro Caliente Especial Colombiano",
      category = FoodCategory.HOT_DOGS,
      description = "Pan brioche artesanal tostado al vapor, salchicha jumbo ahumada, tocineta crocante, lluvia de queso costeño rallado, ripio de papa crocante, salsa de piña y tártara.",
      price = 5.50,
      imageRes = R.drawable.img_hot_dog,
      badge = "Imperdible 🌭",
      preparationTime = "10-12 min",
      ingredients = listOf("Salchicha Jumbo", "Tocineta", "Queso costeño", "Papitas ripio", "Salsa piña", "Salsa tártara"),
      availableExtras = listOf(
        ExtraOption("hd_huevo", "Huevo de Codorniz (2 uds)", 0.80),
        ExtraOption("hd_queso_derretido", "Baño de Queso Cheddar Fundido", 1.20),
        ExtraOption("hd_bacon_bits", "Extra Tocineta Ahumada", 1.25)
      ),
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "hd_2",
      name = "Perro Caliente Callejero Clásico",
      category = FoodCategory.HOT_DOGS,
      description = "Salchicha frankfurt, repollo agridulce rallado, cebolla picadita crocante, lluvia de papas, ketchup clásico, mostaza americana y mayonesa de ajo.",
      price = 4.75,
      imageRes = R.drawable.img_hot_dog,
      badge = "Clásico",
      preparationTime = "8-12 min",
      ingredients = listOf("Salchicha Frankfurt", "Ensalada de repollo", "Cebolla", "Papas ripio", "Salsas tradicionales"),
      availableExtras = commonExtras,
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "hd_3",
      name = "Perro Caliente Mexicano Picante",
      category = FoodCategory.HOT_DOGS,
      description = "Salchicha polaca picada, frijoles refritos negros, queso cheddar derretido, pico de gallo fresco, jalapeños en rodajas y salsa chipotle ahumada.",
      price = 5.95,
      imageRes = R.drawable.img_hot_dog,
      badge = "Picante 🌶️",
      preparationTime = "10-15 min",
      ingredients = listOf("Salchicha polaca", "Jalapeños", "Pico de gallo", "Queso cheddar", "Salsa chipotle"),
      availableExtras = commonExtras,
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),

    // 4. HAMBURGUESAS
    MenuItem(
      id = "bg_1",
      name = "Smash Burger Doble Carne & Tocino",
      category = FoodCategory.HAMBURGUESAS,
      description = "Dos carnes smashed premium de 100g con costra dorada perfecta, doble queso cheddar derretido, abundante tocineta crujiente, cebolla caramelizada y salsa secreta en pan brioche de papa.",
      price = 8.95,
      imageRes = R.drawable.img_burger,
      badge = "Top 1 🍔",
      preparationTime = "15-20 min",
      ingredients = listOf("2x Carne Angus 100g", "Doble Cheddar", "Tocineta ahumada", "Cebolla caramelizada", "Pan Brioche"),
      availableExtras = listOf(
        ExtraOption("bg_patty", "Carne Smashed Adicional (100g)", 2.50),
        ExtraOption("bg_bacon", "Doble Tocineta Ahumada", 1.50),
        ExtraOption("bg_guac", "Guacamole Cremoso", 1.75),
        ExtraOption("bg_huevo", "Huevo Frito a la Plancha", 1.00)
      ),
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "bg_2",
      name = "Burger Monster BBQ & Aros de Cebolla",
      category = FoodCategory.HAMBURGUESAS,
      description = "Carne a la parrilla de 180g, pulled pork bañado en salsa barbacoa ahumada, queso monterey jack y aros de cebolla crocantes dentro del sándwich.",
      price = 9.80,
      imageRes = R.drawable.img_burger,
      badge = "Super Sabor",
      preparationTime = "15-20 min",
      ingredients = listOf("Carne Parrillera 180g", "Pulled Pork", "Aros de cebolla", "Salsa BBQ", "Queso Monterey Jack"),
      availableExtras = commonExtras,
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),
    MenuItem(
      id = "bg_3",
      name = "Burger Crispy Chicken & Guacamole",
      category = FoodCategory.HAMBURGUESAS,
      description = "Pechuga de pollo super crujiente con empanizado especiado, guacamole fresco elaborado al momento, tomate maduro, lechuga romana y mayonesa de cilantro.",
      price = 8.20,
      imageRes = R.drawable.img_burger,
      badge = "Nuevo",
      preparationTime = "12-18 min",
      ingredients = listOf("Pollo Crispy", "Guacamole fresco", "Lechuga", "Tomate", "Pan sésamo"),
      availableExtras = commonExtras,
      availableSides = standardSides,
      availableSpiceLevels = standardSpiceLevels
    ),

    // 5. BEBIDAS Y EXTRAS
    MenuItem(
      id = "dr_1",
      name = "Gaseosa Fría 400ml",
      category = FoodCategory.BEBIDAS,
      description = "Coca-Cola, Sprite, Colombiana, Manzana o Inca Kola bien fría.",
      price = 1.75,
      imageRes = R.drawable.img_burger,
      badge = null,
      preparationTime = "Listo",
      ingredients = listOf("Bebida gaseosa helada"),
      availableExtras = emptyList(),
      availableSides = emptyList(),
      availableSpiceLevels = emptyList()
    ),
    MenuItem(
      id = "dr_2",
      name = "Limonada Natural con Hierbabuena",
      category = FoodCategory.BEBIDAS,
      description = "Fresca limonada recién exprimida con hojas de hierbabuena trituradas y hielo granizado.",
      price = 2.50,
      imageRes = R.drawable.img_tacos,
      badge = "Refrescante",
      preparationTime = "Listo",
      ingredients = listOf("Limón fresco", "Hierbabuena", "Azúcar de caña", "Hielo"),
      availableExtras = emptyList(),
      availableSides = emptyList(),
      availableSpiceLevels = emptyList()
    ),
    MenuItem(
      id = "ex_1",
      name = "Rollitos Primavera / Lumpias Chinas (3 uds)",
      category = FoodCategory.BEBIDAS,
      description = "Rollitos dorados y super crocantes rellenos de vegetales salteados y carne, con salsa agridulce.",
      price = 3.25,
      imageRes = R.drawable.img_arroz_chino,
      badge = "Entrada",
      preparationTime = "10 min",
      ingredients = listOf("Vegetales", "Carne", "Masa crocante", "Salsa agridulce"),
      availableExtras = emptyList(),
      availableSides = emptyList(),
      availableSpiceLevels = standardSpiceLevels
    )
  )

  fun getItemById(id: String): MenuItem? = allItems.find { it.id == id }
}
