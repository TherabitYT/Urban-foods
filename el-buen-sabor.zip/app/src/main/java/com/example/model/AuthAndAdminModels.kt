package com.example.model

data class UserProfile(
  val id: String = "guest_1",
  val name: String = "Invitado",
  val email: String = "",
  val avatarUrl: String? = null,
  val isSignedInWithGoogle: Boolean = false,
  val phoneNumber: String = "+57 301 555 7890"
) {
  companion object {
    val GoogleUserDefault = UserProfile(
      id = "google_carlos_185",
      name = "Carlos Raúl",
      email = "carlosraul185@gmail.com",
      avatarUrl = null,
      isSignedInWithGoogle = true,
      phoneNumber = "+57 301 555 7890"
    )
  }
}

object AdminAuth {
  // Clave maestra especial solicitada por el usuario para gestionar el restaurante
  const val MASTER_KEY: String = "Google123@@"

  fun verifyKey(key: String): Boolean = key.trim() == MASTER_KEY
}

enum class NotificationCategory {
  PEDIDO,
  PROMOCION,
  SISTEMA
}

data class AppNotificationItem(
  val id: String,
  val title: String,
  val message: String,
  val timestamp: Long = System.currentTimeMillis(),
  val category: NotificationCategory,
  val relatedOrderId: String? = null
)
