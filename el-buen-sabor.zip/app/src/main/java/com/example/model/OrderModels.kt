package com.example.model

enum class OrderStatus(
  val stepIndex: Int,
  val title: String,
  val subtitle: String
) {
  CONFIRMADO(
    stepIndex = 1,
    title = "Pedido Confirmado",
    subtitle = "El restaurante ha recibido y verificado tu orden."
  ),
  EN_PREPARACION(
    stepIndex = 2,
    title = "En Preparación en Cocina",
    subtitle = "El chef está en el wok y la parrilla preparando tus platos."
  ),
  EN_CAMINO(
    stepIndex = 3,
    title = "Repartidor en Camino",
    subtitle = "Tu pedido va calientito hacia tu ubicación de entrega."
  ),
  ENTREGADO(
    stepIndex = 4,
    title = "¡Pedido Entregado!",
    subtitle = "El repartidor ha entregado tu comida. ¡Buen provecho!"
  );

  companion object {
    fun fromName(name: String): OrderStatus =
      entries.find { it.name.equals(name, ignoreCase = true) } ?: CONFIRMADO
  }
}

data class DeliveryAddress(
  val id: Long = 0,
  val label: String = "Casa", // Casa, Trabajo, Pareja, etc.
  val street: String = "",
  val numberOrApartment: String = "",
  val neighborhood: String = "",
  val reference: String = "",
  val phone: String = "",
  val isDefault: Boolean = true,
  val latitude: Double = 6.2442,
  val longitude: Double = -75.5812
) {
  val fullDisplayAddress: String
    get() = if (numberOrApartment.isNotBlank()) "$street #$numberOrApartment, $neighborhood" else "$street, $neighborhood"

  val coordinatesDisplay: String
    get() = String.format(java.util.Locale.US, "%.4f°, %.4f°", latitude, longitude)
}

data class OrderItemRecord(
  val menuItemId: String,
  val menuItemName: String,
  val categoryName: String,
  val unitPrice: Double,
  val quantity: Int,
  val selectedExtrasSummary: String = "",
  val specialInstructions: String = ""
) {
  val subtotal: Double
    get() = unitPrice * quantity
}

data class RestaurantOrder(
  val id: String,
  val timestamp: Long = System.currentTimeMillis(),
  val status: OrderStatus = OrderStatus.CONFIRMADO,
  val address: DeliveryAddress,
  val items: List<OrderItemRecord>,
  val subtotal: Double,
  val deliveryFee: Double = 2.50,
  val total: Double,
  val paymentMethod: String = "Efectivo contra entrega",
  val estimatedMinutesRemaining: Int = 25,
  val driverName: String = "Carlos Mendoza",
  val driverPhone: String = "+57 312 884 9201",
  val driverPlate: String = "MOTO-782",
  val driverRating: Float = 4.9f,
  val deliveryProgressPercent: Float = 0.25f
)
