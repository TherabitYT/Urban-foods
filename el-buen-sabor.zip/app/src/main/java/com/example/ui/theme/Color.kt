package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary: Warm fiery grill red-orange
val FlameOrange = Color(0xFFE64A19)
val FlameOrangeLight = Color(0xFFFF7D47)
val FlameOrangeDark = Color(0xFFAC0800)

// Secondary: Golden roasted amber
val AmberGold = Color(0xFFF57C00)
val AmberGoldLight = Color(0xFFFFAD42)
val AmberGoldDark = Color(0xFFBB4D00)

// Tertiary: Fresh cilantro green
val CilantroGreen = Color(0xFF2E7D32)
val CilantroGreenLight = Color(0xFF60AD5E)

// Neutrals Light
val CreamBackground = Color(0xFFFAF7F2)
val CreamSurface = Color(0xFFFFFFFF)
val CreamSurfaceVariant = Color(0xFFF3ECE4)
val CharcoalText = Color(0xFF211A18)
val SubtitleGray = Color(0xFF6B5F58)
val BorderLight = Color(0xFFE6DCD5)

// Status colors
val StatusConfirmed = Color(0xFF1976D2)
val StatusKitchen = Color(0xFFF57C00)
val StatusDelivery = Color(0xFF7B1FA2)
val StatusDelivered = Color(0xFF388E3C)

// Neutrals Dark
val DarkBackground = Color(0xFF171210)
val DarkSurface = Color(0xFF221B18)
val DarkSurfaceVariant = Color(0xFF302622)
val DarkText = Color(0xFFEDE4DF)
val DarkSubtitle = Color(0xFFAFA39D)
