package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.ExtraOption
import com.example.model.FoodCategory
import com.example.model.MenuItem
import com.example.model.SideOption
import com.example.model.SpiceLevel
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AdminDishEditorDialog(
  dish: MenuItem,
  onSaveDish: (MenuItem) -> Unit,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current

  // Basic Info States
  var name by remember { mutableStateOf(dish.name) }
  var selectedCategory by remember { mutableStateOf(dish.category) }
  var isCategoryDropdownOpen by remember { mutableStateOf(false) }
  var description by remember { mutableStateOf(dish.description) }
  var basePriceInput by remember { mutableStateOf(String.format(Locale.US, "%.2f", dish.price)) }
  var prepTime by remember { mutableStateOf(dish.preparationTime) }
  var badge by remember { mutableStateOf(dish.badge ?: "") }

  // Image states
  var selectedImageRes by remember { mutableIntStateOf(dish.imageRes) }
  var customImageUrl by remember { mutableStateOf(dish.customImageUrl ?: "") }

  // Options states (mutable lists for dynamic additions and deletions)
  val extrasList = remember { mutableStateListOf<ExtraOption>().apply { addAll(dish.availableExtras) } }
  val sidesList = remember { mutableStateListOf<SideOption>().apply { addAll(dish.availableSides) } }
  val spiceList = remember { mutableStateListOf<SpiceLevel>().apply { addAll(dish.availableSpiceLevels) } }

  // New option input states
  var newExtraName by remember { mutableStateOf("") }
  var newExtraPrice by remember { mutableStateOf("") }

  var newSideName by remember { mutableStateOf("") }
  var newSidePrice by remember { mutableStateOf("") }

  val imagePresets = listOf(
    Pair("🍔 Burger", R.drawable.img_burger),
    Pair("🌮 Tacos", R.drawable.img_tacos),
    Pair("🍚 Arroz Chino", R.drawable.img_arroz_chino),
    Pair("🌭 Hot Dog", R.drawable.img_hot_dog),
    Pair("👨‍🍳 Logo", R.drawable.ic_restaurant_logo)
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Edit,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
          Text(
            text = "Gestionar Servicio / Platillo",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Modifica imagen, precios y agrega opciones al menú",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // ---------------- 1. SECCIÓN: MODIFICAR IMAGEN ----------------
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Image, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("1. Modificar Imagen del Servicio", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Real-time image preview
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black.copy(alpha = 0.05f))
            ) {
              if (customImageUrl.isNotBlank()) {
                AsyncImage(
                  model = customImageUrl,
                  contentDescription = name,
                  placeholder = painterResource(id = selectedImageRes),
                  error = painterResource(id = selectedImageRes),
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
              } else {
                Image(
                  painter = painterResource(id = selectedImageRes),
                  contentDescription = name,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
              }
              Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(topStart = 8.dp),
                modifier = Modifier.align(Alignment.BottomEnd)
              ) {
                Text(
                  text = if (customImageUrl.isNotBlank()) "URL Web Personalizada" else "Imagen Preestablecida",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text("Seleccionar Imagen de Galería:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              imagePresets.forEach { (label, res) ->
                FilterChip(
                  selected = selectedImageRes == res && customImageUrl.isBlank(),
                  onClick = {
                    selectedImageRes = res
                    customImageUrl = "" // clear custom URL when selecting preset
                  },
                  label = { Text(label, fontSize = 11.sp) }
                )
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
              value = customImageUrl,
              onValueChange = { customImageUrl = it },
              label = { Text("O URL de Imagen en Internet (http/https)") },
              placeholder = { Text("https://ejemplo.com/mi-plato.jpg") },
              leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
              trailingIcon = {
                if (customImageUrl.isNotBlank()) {
                  IconButton(onClick = { customImageUrl = "" }) {
                    Icon(Icons.Default.Close, contentDescription = "Limpiar URL")
                  }
                }
              },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("input_custom_image_url")
            )
          }
        }

        // ---------------- 2. SECCIÓN: DATOS BÁSICOS & PRECIO BASE ----------------
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("2. Precio del Servicio e Información", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = name,
              onValueChange = { name = it },
              label = { Text("Nombre del Plato *") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("input_edit_dish_name")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedTextField(
                value = basePriceInput,
                onValueChange = { basePriceInput = it },
                label = { Text("Precio Base ($) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_edit_base_price")
              )

              OutlinedTextField(
                value = prepTime,
                onValueChange = { prepTime = it },
                label = { Text("Tiempo Prep.") },
                singleLine = true,
                modifier = Modifier.weight(1f)
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Category selector
            ExposedDropdownMenuBox(
              expanded = isCategoryDropdownOpen,
              onExpandedChange = { isCategoryDropdownOpen = !isCategoryDropdownOpen }
            ) {
              OutlinedTextField(
                value = "${selectedCategory.iconText} ${selectedCategory.displayName}",
                onValueChange = {},
                readOnly = true,
                label = { Text("Categoría") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCategoryDropdownOpen) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
              )
              ExposedDropdownMenu(
                expanded = isCategoryDropdownOpen,
                onDismissRequest = { isCategoryDropdownOpen = false }
              ) {
                FoodCategory.entries.filter { it != FoodCategory.TODOS }.forEach { cat ->
                  DropdownMenuItem(
                    text = { Text("${cat.iconText} ${cat.displayName}") },
                    onClick = {
                      selectedCategory = cat
                      isCategoryDropdownOpen = false
                    }
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = description,
              onValueChange = { description = it },
              label = { Text("Descripción del Plato") },
              maxLines = 3,
              modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = badge,
              onValueChange = { badge = it },
              label = { Text("Etiqueta Promocional (Badge)") },
              placeholder = { Text("Ej: 2x1, Más Vendido, Recomendado") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )
          }
        }

        // ---------------- 3. SECCIÓN: AGREGAR OPCIONES Y PRECIOS (EXTRAS) ----------------
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("3. Extras / Toppings Personalizables", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              }
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = MaterialTheme.colorScheme.primaryContainer
              ) {
                Text(
                  text = "${extrasList.size} opciones",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Current extras list with price and delete
            extrasList.forEachIndexed { index, extra ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(text = extra.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Text(
                      text = "+${String.format(Locale.US, "$%.2f", extra.price)} al pedido",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                  IconButton(
                    onClick = { extrasList.removeAt(index) },
                    modifier = Modifier.size(32.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.Delete,
                      contentDescription = "Eliminar extra",
                      tint = MaterialTheme.colorScheme.error,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text("Agregar Nueva Opción de Extra:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedTextField(
                value = newExtraName,
                onValueChange = { newExtraName = it },
                placeholder = { Text("Ej: Aguacate Hass") },
                singleLine = true,
                modifier = Modifier.weight(1.5f).testTag("input_new_extra_name")
              )
              OutlinedTextField(
                value = newExtraPrice,
                onValueChange = { newExtraPrice = it },
                placeholder = { Text("$1.50") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_new_extra_price")
              )
              Button(
                onClick = {
                  val parsed = newExtraPrice.toDoubleOrNull() ?: 1.0
                  if (newExtraName.isNotBlank()) {
                    extrasList.add(
                      ExtraOption(
                        id = "ext_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}",
                        name = newExtraName.trim(),
                        price = parsed
                      )
                    )
                    newExtraName = ""
                    newExtraPrice = ""
                  }
                },
                enabled = newExtraName.isNotBlank(),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
              ) {
                Icon(Icons.Default.Add, contentDescription = "Añadir")
              }
            }
          }
        }

        // ---------------- 4. SECCIÓN: GUARNICIONES / ACOMPAÑAMIENTOS ----------------
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("4. Guarniciones y Acompañamientos", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
              }
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = MaterialTheme.colorScheme.primaryContainer
              ) {
                Text(
                  text = "${sidesList.size} opciones",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            sidesList.forEachIndexed { index, side ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text(text = side.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Text(
                      text = if (side.price > 0) "+${String.format(Locale.US, "$%.2f", side.price)}" else "Incluido sin costo",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                  IconButton(
                    onClick = { sidesList.removeAt(index) },
                    modifier = Modifier.size(32.dp)
                  ) {
                    Icon(
                      imageVector = Icons.Default.Delete,
                      contentDescription = "Eliminar guarnición",
                      tint = MaterialTheme.colorScheme.error,
                      modifier = Modifier.size(18.dp)
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text("Agregar Nueva Guarnición:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedTextField(
                value = newSideName,
                onValueChange = { newSideName = it },
                placeholder = { Text("Ej: Aros de Cebolla") },
                singleLine = true,
                modifier = Modifier.weight(1.5f).testTag("input_new_side_name")
              )
              OutlinedTextField(
                value = newSidePrice,
                onValueChange = { newSidePrice = it },
                placeholder = { Text("$2.00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_new_side_price")
              )
              Button(
                onClick = {
                  val parsed = newSidePrice.toDoubleOrNull() ?: 0.0
                  if (newSideName.isNotBlank()) {
                    sidesList.add(
                      SideOption(
                        id = "side_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}",
                        name = newSideName.trim(),
                        price = parsed
                      )
                    )
                    newSideName = ""
                    newSidePrice = ""
                  }
                },
                enabled = newSideName.isNotBlank(),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
              ) {
                Icon(Icons.Default.Add, contentDescription = "Añadir")
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val parsedPrice = basePriceInput.toDoubleOrNull()
          if (name.isNotBlank() && parsedPrice != null && parsedPrice > 0) {
            val updatedDish = dish.copy(
              name = name.trim(),
              category = selectedCategory,
              description = description.trim(),
              price = parsedPrice,
              imageRes = selectedImageRes,
              customImageUrl = customImageUrl.ifBlank { null },
              badge = badge.ifBlank { null },
              preparationTime = prepTime.ifBlank { "15-20 min" },
              availableExtras = extrasList.toList(),
              availableSides = sidesList.toList(),
              availableSpiceLevels = spiceList.toList()
            )
            onSaveDish(updatedDish)
            Toast.makeText(context, "¡Platillo '${updatedDish.name}' actualizado!", Toast.LENGTH_SHORT).show()
            onDismiss()
          } else {
            Toast.makeText(context, "Por favor ingresa un nombre y precio válido.", Toast.LENGTH_SHORT).show()
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier.testTag("save_dish_editor_button")
      ) {
        Text("Guardar Cambios", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("Cancelar")
      }
    }
  )
}
