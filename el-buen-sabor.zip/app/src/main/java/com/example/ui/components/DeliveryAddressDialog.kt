package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeliveryAddress

@Composable
fun DeliveryAddressDialog(
  savedAddresses: List<DeliveryAddress>,
  currentAddress: DeliveryAddress?,
  onSelectSavedAddress: (DeliveryAddress) -> Unit,
  onSaveNewAddress: (
    label: String,
    street: String,
    number: String,
    neighborhood: String,
    reference: String,
    phone: String,
    setAsDefault: Boolean,
    latitude: Double,
    longitude: Double
  ) -> Unit,
  onDismiss: () -> Unit
) {
  var isAddingNew by remember { mutableStateOf(savedAddresses.isEmpty()) }
  var showGoogleMapsPicker by remember { mutableStateOf(false) }

  var label by remember { mutableStateOf("Casa") }
  var street by remember { mutableStateOf(currentAddress?.street ?: "") }
  var number by remember { mutableStateOf(currentAddress?.numberOrApartment ?: "") }
  var neighborhood by remember { mutableStateOf(currentAddress?.neighborhood ?: "") }
  var reference by remember { mutableStateOf(currentAddress?.reference ?: "") }
  var phone by remember { mutableStateOf(currentAddress?.phone ?: "+57 300 123 4567") }
  var setAsDefault by remember { mutableStateOf(true) }

  var latitude by remember { mutableDoubleStateOf(currentAddress?.latitude ?: 6.2442) }
  var longitude by remember { mutableDoubleStateOf(currentAddress?.longitude ?: -75.5812) }
  var hasPickedFromMap by remember { mutableStateOf(false) }

  if (showGoogleMapsPicker) {
    GoogleMapsLocationPickerDialog(
      initialAddress = currentAddress,
      onLocationSelected = { mapStreet, mapNeighborhood, mapLat, mapLng, mapRef ->
        street = mapStreet
        neighborhood = mapNeighborhood
        latitude = mapLat
        longitude = mapLng
        if (mapRef.isNotBlank()) reference = mapRef
        hasPickedFromMap = true
        isAddingNew = true
        showGoogleMapsPicker = false
      },
      onDismiss = { showGoogleMapsPicker = false }
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.LocationOn,
          contentDescription = "Ubicación",
          tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isAddingNew) "Nueva Ubicación de Entrega" else "Dirección de Delivery",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Prominent Google Maps Picker Trigger Button
        Button(
          onClick = { showGoogleMapsPicker = true },
          colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF1A73E8)
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("open_google_maps_picker_button")
        ) {
          Icon(
            imageVector = Icons.Default.Map,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Seleccionar en Google Maps",
            color = Color.White,
            fontWeight = FontWeight.Bold
          )
        }

        if (hasPickedFromMap) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF34A853).copy(alpha = 0.12f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF137333),
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = "Ubicación GPS fijada en Google Maps",
                  style = MaterialTheme.typography.labelMedium,
                  color = Color(0xFF137333),
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = String.format(java.util.Locale.US, "Lat: %.4f°, Lng: %.4f°", latitude, longitude),
                  style = MaterialTheme.typography.labelSmall,
                  color = Color(0xFF137333)
                )
              }
            }
          }
        }

        if (!isAddingNew && savedAddresses.isNotEmpty()) {
          Text(
            text = "Direcciones Guardadas:",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          savedAddresses.forEach { address ->
            val isSelected = currentAddress?.street == address.street && currentAddress.neighborhood == address.neighborhood
            Card(
              colors = CardDefaults.cardColors(
                containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
              ),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onSelectSavedAddress(address)
                  onDismiss()
                }
                .testTag("saved_address_${address.id}")
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = if (address.label.contains("Trabajo", ignoreCase = true)) Icons.Default.Work else Icons.Default.Home,
                  contentDescription = address.label,
                  tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = address.label,
                      fontWeight = FontWeight.Bold,
                      style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                      shape = RoundedCornerShape(4.dp),
                      color = Color(0xFF4285F4).copy(alpha = 0.15f)
                    ) {
                      Text(
                        text = "Maps GPS",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        color = Color(0xFF1A73E8),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                      )
                    }
                  }
                  Text(
                    text = address.fullDisplayAddress,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Text(
                    text = "📍 ${address.coordinatesDisplay}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF1A73E8),
                    fontWeight = FontWeight.SemiBold
                  )
                  if (address.reference.isNotBlank()) {
                    Text(
                      text = "Ref: ${address.reference}",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.outline
                    )
                  }
                }
                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Seleccionada",
                    tint = MaterialTheme.colorScheme.primary
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(4.dp))
          OutlinedButton(
            onClick = { isAddingNew = true },
            modifier = Modifier.fillMaxWidth().testTag("add_new_address_button")
          ) {
            Text("+ Agregar Otra Dirección")
          }
        } else {
          // Form to add new address
          Text(
            text = "Tipo de lugar:",
            style = MaterialTheme.typography.labelMedium
          )
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            listOf("Casa", "Trabajo", "Pareja", "Otro").forEach { option ->
              FilterChip(
                selected = label == option,
                onClick = { label = option },
                label = { Text(option) },
                modifier = Modifier.testTag("chip_label_$option")
              )
            }
          }

          OutlinedTextField(
            value = street,
            onValueChange = { street = it },
            label = { Text("Calle / Carrera / Avenida *") },
            placeholder = { Text("Ej: Calle 45 o Carrera 15") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_street")
          )

          OutlinedTextField(
            value = number,
            onValueChange = { number = it },
            label = { Text("Número / Apto / Casa *") },
            placeholder = { Text("Ej: # 18-32, Apto 402") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_number")
          )

          OutlinedTextField(
            value = neighborhood,
            onValueChange = { neighborhood = it },
            label = { Text("Barrio / Sector *") },
            placeholder = { Text("Ej: La Floresta / Chapinero") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_neighborhood")
          )

          OutlinedTextField(
            value = reference,
            onValueChange = { reference = it },
            label = { Text("Indicaciones para el repartidor") },
            placeholder = { Text("Ej: Edificio blanco frente al parque, timbre 402") },
            modifier = Modifier.fillMaxWidth().testTag("input_reference")
          )

          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Teléfono de contacto *") },
            placeholder = { Text("+57 300 000 0000") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().testTag("input_phone")
          )

          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "Guardar como dirección principal",
              style = MaterialTheme.typography.bodyMedium,
              modifier = Modifier.weight(1f)
            )
            Switch(
              checked = setAsDefault,
              onCheckedChange = { setAsDefault = it },
              modifier = Modifier.testTag("switch_default_address")
            )
          }

          if (savedAddresses.isNotEmpty()) {
            OutlinedButton(
              onClick = { isAddingNew = false },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("Volver a mis direcciones")
            }
          }
        }
      }
    },
    confirmButton = {
      if (isAddingNew) {
        Button(
          onClick = {
            if (street.isNotBlank()) {
              onSaveNewAddress(
                label,
                street,
                number,
                neighborhood.ifBlank { "Ciudad" },
                reference,
                phone,
                setAsDefault,
                latitude,
                longitude
              )
            }
          },
          enabled = street.isNotBlank(),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          modifier = Modifier.testTag("save_address_button")
        ) {
          Text("Guardar y Usar")
        }
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, modifier = Modifier.testTag("cancel_address_button")) {
        Text("Cerrar")
      }
    }
  )
}
