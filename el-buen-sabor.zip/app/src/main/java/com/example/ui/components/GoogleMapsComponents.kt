package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.DeliveryAddress
import com.example.model.OrderStatus
import com.example.model.RestaurantOrder
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

enum class MapThemeType(val label: String, val icon: String) {
  STREETS("Calles", "🗺️"),
  SATELLITE("Satelital", "🛰️"),
  TERRAIN("Terreno", "🏔️")
}

/**
 * Interactive Google Maps Location Picker Dialog.
 * Allows users to tap or drag the pin anywhere on the street map,
 * displays exact Latitude & Longitude, reverse-geocodes to an address,
 * and returns the chosen location.
 */
@Composable
fun GoogleMapsLocationPickerDialog(
  initialAddress: DeliveryAddress?,
  onLocationSelected: (
    street: String,
    neighborhood: String,
    latitude: Double,
    longitude: Double,
    reference: String
  ) -> Unit,
  onDismiss: () -> Unit
) {
  // Base reference coordinate: Medellin / Poblado / Chapinero reference frame
  val baseLat = 6.2442
  val baseLng = -75.5812

  var pinNormalizedX by remember { mutableFloatStateOf(0.5f) }
  var pinNormalizedY by remember { mutableFloatStateOf(0.5f) }
  var zoomLevel by remember { mutableFloatStateOf(1.0f) }
  var mapTheme by remember { mutableStateOf(MapThemeType.STREETS) }

  var streetText by remember { mutableStateOf(initialAddress?.street?.ifBlank { "Calle 45 # 18-32" } ?: "Calle 45 # 18-32") }
  var neighborhoodText by remember { mutableStateOf(initialAddress?.neighborhood?.ifBlank { "La Floresta" } ?: "La Floresta") }
  var referenceText by remember { mutableStateOf(initialAddress?.reference ?: "") }

  // Calculate live latitude & longitude from pin normalized position
  val currentLat = baseLat + ((0.5f - pinNormalizedY) * 0.035 * (1.0 / zoomLevel))
  val currentLng = baseLng + ((pinNormalizedX - 0.5f) * 0.045 * (1.0 / zoomLevel))

  // Update approximate street address when pin moves significantly
  fun updateReverseGeocode(normX: Float, normY: Float) {
    val sectorX = (normX * 10).roundToInt().coerceIn(1, 9)
    val sectorY = (normY * 10).roundToInt().coerceIn(1, 9)

    val streetName = when {
      sectorY <= 3 -> "Avenida El Poblado # ${sectorX * 8}-${sectorY * 12}"
      sectorY in 4..6 -> "Carrera ${10 + sectorX * 4} # ${sectorY * 10}-${sectorX * 3}"
      else -> "Calle ${40 + sectorY * 3} # ${15 + sectorX * 2}-${sectorY * 5}"
    }

    val hood = when {
      normX < 0.35f && normY < 0.4f -> "La Castellana"
      normX > 0.65f && normY < 0.4f -> "El Poblado / Provenza"
      normX < 0.5f && normY > 0.6f -> "La Floresta"
      normX >= 0.5f && normY > 0.6f -> "Laureles / Conquistadores"
      else -> "Sector Centro / Principal"
    }

    streetText = streetName
    neighborhoodText = hood
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 12.dp, vertical = 20.dp),
      shape = RoundedCornerShape(24.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 6.dp
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Top Header
        Surface(
          color = MaterialTheme.colorScheme.surface,
          shadowElevation = 2.dp
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = Color(0xFF4285F4).copy(alpha = 0.15f),
                modifier = Modifier.size(38.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = Color(0xFFEA4335), // Google Maps Pin Red
                    modifier = Modifier.size(24.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "Google Maps",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFF34A853).copy(alpha = 0.15f)
                  ) {
                    Text(
                      text = "GPS VIVO",
                      style = MaterialTheme.typography.labelSmall,
                      fontSize = 9.sp,
                      color = Color(0xFF137333),
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                  }
                }
                Text(
                  text = "Toca el mapa para fijar tu ubicación exacta",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            IconButton(
              onClick = onDismiss,
              modifier = Modifier.testTag("close_map_picker_btn")
            ) {
              Icon(Icons.Default.Close, contentDescription = "Cerrar")
            }
          }
        }

        // Map Viewport (Takes weight of screen)
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .clip(RoundedCornerShape(0.dp))
        ) {
          // Interactive Map Canvas
          Canvas(
            modifier = Modifier
              .fillMaxSize()
              .pointerInput(zoomLevel) {
                detectTapGestures { offset ->
                  val normX = (offset.x / size.width).coerceIn(0.05f, 0.95f)
                  val normY = (offset.y / size.height).coerceIn(0.05f, 0.95f)
                  pinNormalizedX = normX
                  pinNormalizedY = normY
                  updateReverseGeocode(normX, normY)
                }
              }
              .pointerInput(zoomLevel) {
                detectDragGestures { change, _ ->
                  change.consume()
                  val normX = (change.position.x / size.width).coerceIn(0.05f, 0.95f)
                  val normY = (change.position.y / size.height).coerceIn(0.05f, 0.95f)
                  pinNormalizedX = normX
                  pinNormalizedY = normY
                  updateReverseGeocode(normX, normY)
                }
              }
          ) {
            drawGoogleMapGrid(
              size = size,
              theme = mapTheme,
              zoom = zoomLevel,
              centerBias = Offset(pinNormalizedX, pinNormalizedY)
            )

            // Draw animated GPS ripple at pin location
            val pinPixel = Offset(size.width * pinNormalizedX, size.height * pinNormalizedY)

            // Radar accuracy ring
            drawCircle(
              color = Color(0xFF4285F4).copy(alpha = 0.25f),
              radius = 28f * zoomLevel,
              center = pinPixel
            )
            drawCircle(
              color = Color(0xFF4285F4).copy(alpha = 0.45f),
              radius = 16f * zoomLevel,
              center = pinPixel,
              style = Stroke(width = 2f)
            )

            // Pin shadow
            drawOval(
              color = Color.Black.copy(alpha = 0.35f),
              topLeft = Offset(pinPixel.x - 12f, pinPixel.y + 12f),
              size = Size(24f, 8f)
            )

            // Main Google Pin Body
            drawCircle(
              color = Color(0xFFEA4335), // Google Red
              radius = 15f,
              center = Offset(pinPixel.x, pinPixel.y - 14f)
            )
            // Pin Inner white dot
            drawCircle(
              color = Color.White,
              radius = 6f,
              center = Offset(pinPixel.x, pinPixel.y - 14f)
            )
          }

          // Top floating Map Theme toggle
          Row(
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            MapThemeType.entries.forEach { themeOption ->
              val isSelected = mapTheme == themeOption
              Surface(
                onClick = { mapTheme = themeOption },
                shape = RoundedCornerShape(20.dp),
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                shadowElevation = 3.dp,
                modifier = Modifier.height(32.dp)
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.padding(horizontal = 10.dp)
                ) {
                  Text(text = themeOption.icon, fontSize = 12.sp)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = themeOption.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                  )
                }
              }
            }
          }

          // Right floating Zoom & GPS controls
          Column(
            modifier = Modifier
              .align(Alignment.CenterEnd)
              .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Zoom In
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.surface,
              shadowElevation = 4.dp,
              modifier = Modifier.size(40.dp),
              onClick = { zoomLevel = (zoomLevel + 0.25f).coerceAtMost(2.5f) }
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, contentDescription = "Acercar", tint = MaterialTheme.colorScheme.onSurface)
              }
            }

            // Zoom Out
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.surface,
              shadowElevation = 4.dp,
              modifier = Modifier.size(40.dp),
              onClick = { zoomLevel = (zoomLevel - 0.25f).coerceAtLeast(0.75f) }
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Remove, contentDescription = "Alejar", tint = MaterialTheme.colorScheme.onSurface)
              }
            }

            // My GPS Location (Recenter)
            Surface(
              shape = CircleShape,
              color = Color(0xFF4285F4),
              shadowElevation = 5.dp,
              modifier = Modifier.size(44.dp),
              onClick = {
                pinNormalizedX = 0.5f
                pinNormalizedY = 0.5f
                zoomLevel = 1.0f
                updateReverseGeocode(0.5f, 0.5f)
              }
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MyLocation, contentDescription = "Mi Ubicación", tint = Color.White)
              }
            }
          }

          // Floating Lat/Lng Coordinate Badge
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.Black.copy(alpha = 0.75f),
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(12.dp)
          ) {
            Text(
              text = String.format(Locale.US, "📍 Lat: %.5f | Lng: %.5f", currentLat, currentLng),
              color = Color.White,
              style = MaterialTheme.typography.labelSmall,
              fontSize = 10.sp,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }

        // Bottom Form & Confirm Section
        Surface(
          color = MaterialTheme.colorScheme.surface,
          shadowElevation = 8.dp,
          shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = streetText,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = "$neighborhoodText • Coordenadas exactas fijadas",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.primary,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }

            OutlinedTextField(
              value = referenceText,
              onValueChange = { referenceText = it },
              label = { Text("Instrucciones de llegada (ej: timbre, casa amarilla)") },
              singleLine = true,
              modifier = Modifier
                .fillMaxWidth()
                .testTag("map_picker_reference_input")
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
              ) {
                Text("Cancelar")
              }

              Button(
                onClick = {
                  onLocationSelected(
                    streetText,
                    neighborhoodText,
                    currentLat,
                    currentLng,
                    referenceText
                  )
                  onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .weight(2f)
                  .testTag("confirm_map_location_button")
              ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Fijar Ubicación de Entrega", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

/**
 * Enhanced Google Maps Real-Time Tracking View.
 * Displays Restaurant Hub, Customer Location, dynamic Route Polyline,
 * and an animated Delivery Rider moving with speed and distance HUD.
 */
@Composable
fun GoogleMapsLiveTrackingView(
  order: RestaurantOrder,
  onOpenChat: () -> Unit,
  modifier: Modifier = Modifier
) {
  var mapTheme by remember { mutableStateOf(MapThemeType.STREETS) }
  var zoomLevel by remember { mutableFloatStateOf(1.0f) }
  var followRider by remember { mutableStateOf(true) }

  val deliveryProgress = order.deliveryProgressPercent.coerceIn(0.05f, 1.0f)

  val infiniteTransition = rememberInfiniteTransition(label = "pulse_radar")
  val radarPulse by infiniteTransition.animateFloat(
    initialValue = 0.8f,
    targetValue = 1.4f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "radarPulse"
  )

  // Speed calculation based on order status
  val simulatedSpeed = when (order.status) {
    OrderStatus.EN_CAMINO -> 34
    OrderStatus.EN_PREPARACION -> 0
    OrderStatus.CONFIRMADO -> 0
    OrderStatus.ENTREGADO -> 0
  }

  val simulatedDistanceRemaining = when (order.status) {
    OrderStatus.CONFIRMADO -> "3.2 km"
    OrderStatus.EN_PREPARACION -> "2.8 km"
    OrderStatus.EN_CAMINO -> String.format(Locale.US, "%.1f km", (3.2 * (1.0f - deliveryProgress)).coerceAtLeast(0.1))
    OrderStatus.ENTREGADO -> "0.0 km"
  }

  val currentRoadName = when {
    deliveryProgress < 0.25f -> "Saliendo de Cocina: Carrera 43A"
    deliveryProgress < 0.55f -> "Transitando por Av. Las Vegas a 34 km/h"
    deliveryProgress < 0.85f -> "Girando hacia Calle 45"
    deliveryProgress < 1.0f -> "Llegando a la dirección de entrega"
    else -> "¡Repartidor en puerta!"
  }

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("google_maps_live_tracking_card")
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Map Header Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = CircleShape,
            color = Color(0xFF4285F4).copy(alpha = 0.15f),
            modifier = Modifier.size(30.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Navigation,
                contentDescription = null,
                tint = Color(0xFF1A73E8),
                modifier = Modifier.size(16.dp)
              )
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "Google Maps Seguimiento",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = currentRoadName,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        // Live Radar Badge
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = if (order.status == OrderStatus.EN_CAMINO) Color(0xFF1B873F) else MaterialTheme.colorScheme.surfaceVariant
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(if (order.status == OrderStatus.EN_CAMINO) Color.White else MaterialTheme.colorScheme.outline)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (order.status == OrderStatus.EN_CAMINO) "EN VIVO" else order.status.name,
              color = if (order.status == OrderStatus.EN_CAMINO) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
              style = MaterialTheme.typography.labelSmall,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // Map Canvas Box
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(240.dp)
          .clip(RoundedCornerShape(0.dp))
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height

          // Draw base city map with street networks and parks
          drawGoogleMapGrid(size, mapTheme, zoomLevel, Offset(0.5f, 0.5f))

          // Fixed restaurant origin (top left)
          val restaurantPoint = Offset(w * 0.18f, h * 0.22f)
          // Waypoint 1: turn into main avenue
          val way1 = Offset(w * 0.48f, h * 0.22f)
          // Waypoint 2: avenue traverse
          val way2 = Offset(w * 0.48f, h * 0.76f)
          // Customer Destination (bottom right)
          val customerPoint = Offset(w * 0.82f, h * 0.76f)

          val fullRoutePath = Path().apply {
            moveTo(restaurantPoint.x, restaurantPoint.y)
            lineTo(way1.x, way1.y)
            lineTo(way2.x, way2.y)
            lineTo(customerPoint.x, customerPoint.y)
          }

          // Total route segment lengths
          val len1 = abs(way1.x - restaurantPoint.x)
          val len2 = abs(way2.y - way1.y)
          val len3 = abs(customerPoint.x - way2.x)
          val totalLen = len1 + len2 + len3

          // Calculate current rider coordinates along the path
          val riderDistance = totalLen * deliveryProgress
          val riderPos = when {
            riderDistance <= len1 -> {
              val frac = (riderDistance / len1).coerceIn(0f, 1f)
              Offset(restaurantPoint.x + (way1.x - restaurantPoint.x) * frac, restaurantPoint.y)
            }
            riderDistance <= (len1 + len2) -> {
              val frac = ((riderDistance - len1) / len2).coerceIn(0f, 1f)
              Offset(way1.x, way1.y + (way2.y - way1.y) * frac)
            }
            else -> {
              val frac = ((riderDistance - len1 - len2) / len3).coerceIn(0f, 1f)
              Offset(way2.x + (customerPoint.x - way2.x) * frac, customerPoint.y)
            }
          }

          // Draw full planned route in dashed blue Google Maps style
          drawPath(
            path = fullRoutePath,
            color = Color(0xFF4285F4).copy(alpha = 0.5f),
            style = Stroke(
              width = 8f,
              cap = StrokeCap.Round,
              pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f), 0f)
            )
          )

          // Draw traveled route in solid vibrant blue Google route color
          val traveledPath = Path().apply {
            moveTo(restaurantPoint.x, restaurantPoint.y)
            if (riderDistance > len1) {
              lineTo(way1.x, way1.y)
              if (riderDistance > len1 + len2) {
                lineTo(way2.x, way2.y)
              }
            }
            lineTo(riderPos.x, riderPos.y)
          }
          drawPath(
            path = traveledPath,
            color = Color(0xFF1A73E8),
            style = Stroke(width = 8f, cap = StrokeCap.Round)
          )

          // 1. Draw Restaurant Hub Pin
          drawCircle(Color(0xFFEA4335), radius = 14f, center = restaurantPoint)
          drawCircle(Color.White, radius = 6f, center = restaurantPoint)

          // 2. Draw Customer Destination Pin with Pulsing Radar
          drawCircle(
            color = Color(0xFF34A853).copy(alpha = 0.3f),
            radius = 26f * radarPulse,
            center = customerPoint
          )
          drawCircle(Color(0xFF34A853), radius = 14f, center = customerPoint)
          drawCircle(Color.White, radius = 6f, center = customerPoint)

          // 3. Draw Delivery Rider Marker (Motorcycle Circle with Radar)
          drawCircle(
            color = Color(0xFF1A73E8).copy(alpha = 0.35f),
            radius = 24f * radarPulse,
            center = riderPos
          )
          drawCircle(Color.White, radius = 16f, center = riderPos)
          drawCircle(Color(0xFF1A73E8), radius = 13f, center = riderPos)
          drawCircle(Color.White, radius = 5f, center = riderPos)
        }

        // Top-left Map Layers Toggle
        Row(
          modifier = Modifier
            .align(Alignment.TopStart)
            .padding(8.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          MapThemeType.entries.forEach { option ->
            Surface(
              onClick = { mapTheme = option },
              shape = RoundedCornerShape(14.dp),
              color = if (mapTheme == option) Color(0xFF1A73E8) else MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
              shadowElevation = 2.dp,
              modifier = Modifier.height(28.dp)
            ) {
              Text(
                text = "${option.icon} ${option.label}",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (mapTheme == option) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
              )
            }
          }
        }

        // Right side Zoom controls
        Column(
          modifier = Modifier
            .align(Alignment.CenterEnd)
            .padding(8.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp,
            modifier = Modifier.size(32.dp),
            onClick = { zoomLevel = (zoomLevel + 0.2f).coerceAtMost(2.0f) }
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            }
          }
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp,
            modifier = Modifier.size(32.dp),
            onClick = { zoomLevel = (zoomLevel - 0.2f).coerceAtLeast(0.8f) }
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
            }
          }
        }

        // Floating Telemetry Overlay (Speedometer & Distance HUD)
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color.Black.copy(alpha = 0.8f),
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(10.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              Icons.Default.Speed,
              contentDescription = null,
              tint = Color(0xFFFBBC04), // Google Yellow
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "$simulatedSpeed km/h",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = "•", color = Color.Gray)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "Distancia: $simulatedDistanceRemaining",
              color = Color.White,
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp
            )
          }
        }
      }

      // Bottom Pin Legend & Quick Driver Call/Chat
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFEA4335)))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Restaurante", style = MaterialTheme.typography.labelSmall)
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF1A73E8)))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Repartidor", style = MaterialTheme.typography.labelSmall)
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF34A853)))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Tu Casa", style = MaterialTheme.typography.labelSmall)
          }
        }

        OutlinedButton(
          onClick = onOpenChat,
          shape = RoundedCornerShape(8.dp),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier.height(30.dp)
        ) {
          Text("💬 Chat Repartidor", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

/**
 * Custom Canvas Drawing Helper that mimics Google Maps vector tiles.
 * Supports Street, Satellite, and Terrain themes.
 */
private fun DrawScope.drawGoogleMapGrid(
  size: Size,
  theme: MapThemeType,
  zoom: Float,
  centerBias: Offset
) {
  val w = size.width
  val h = size.height

  when (theme) {
    MapThemeType.STREETS -> {
      // Light Google Maps background
      drawRect(Color(0xFFF2EFE9))

      // Parks & Green Areas
      drawRect(
        color = Color(0xFFCEE6C3),
        topLeft = Offset(w * 0.05f, h * 0.65f),
        size = Size(w * 0.35f, h * 0.28f)
      )
      drawRect(
        color = Color(0xFFCEE6C3),
        topLeft = Offset(w * 0.65f, h * 0.08f),
        size = Size(w * 0.28f, h * 0.22f)
      )

      // Water body / River
      val riverPath = Path().apply {
        moveTo(0f, h * 0.45f)
        cubicTo(w * 0.3f, h * 0.40f, w * 0.6f, h * 0.55f, w, h * 0.48f)
        lineTo(w, h * 0.54f)
        cubicTo(w * 0.6f, h * 0.61f, w * 0.3f, h * 0.46f, 0f, h * 0.51f)
        close()
      }
      drawPath(riverPath, color = Color(0xFFAAD3DF))

      // Building Blocks
      val blockColor = Color(0xFFE8E5DD)
      for (i in 0..4) {
        for (j in 0..3) {
          val bx = (w * (0.05f + i * 0.20f))
          val by = (h * (0.06f + j * 0.24f))
          drawRect(
            color = blockColor,
            topLeft = Offset(bx, by),
            size = Size(w * 0.12f, h * 0.14f)
          )
        }
      }

      // Secondary Streets
      val streetBorder = Color(0xFFDAD3C8)
      val streetWhite = Color.White

      val hStreets = listOf(h * 0.22f, h * 0.48f, h * 0.76f)
      hStreets.forEach { y ->
        drawLine(streetBorder, Offset(0f, y), Offset(w, y), strokeWidth = 22f * zoom)
        drawLine(streetWhite, Offset(0f, y), Offset(w, y), strokeWidth = 16f * zoom)
      }

      val vStreets = listOf(w * 0.18f, w * 0.48f, w * 0.82f)
      vStreets.forEach { x ->
        drawLine(streetBorder, Offset(x, 0f), Offset(x, h), strokeWidth = 22f * zoom)
        drawLine(streetWhite, Offset(x, 0f), Offset(x, h), strokeWidth = 16f * zoom)
      }

      // Main Primary Avenue (Google Yellow / Orange Tint)
      val avBorder = Color(0xFFE5C158)
      val avYellow = Color(0xFFFFEB8B)
      drawLine(avBorder, Offset(0f, h * 0.48f), Offset(w, h * 0.48f), strokeWidth = 28f * zoom)
      drawLine(avYellow, Offset(0f, h * 0.48f), Offset(w, h * 0.48f), strokeWidth = 22f * zoom)
    }

    MapThemeType.SATELLITE -> {
      // Dark earth satellite background
      drawRect(Color(0xFF263238))

      // Terrain variations
      drawRect(Color(0xFF1B2B24), topLeft = Offset(w * 0.05f, h * 0.65f), size = Size(w * 0.35f, h * 0.28f))
      drawRect(Color(0xFF1E3228), topLeft = Offset(w * 0.65f, h * 0.08f), size = Size(w * 0.28f, h * 0.22f))

      // River in dark navy
      val riverPath = Path().apply {
        moveTo(0f, h * 0.45f)
        cubicTo(w * 0.3f, h * 0.40f, w * 0.6f, h * 0.55f, w, h * 0.48f)
        lineTo(w, h * 0.54f)
        cubicTo(w * 0.6f, h * 0.61f, w * 0.3f, h * 0.46f, 0f, h * 0.51f)
        close()
      }
      drawPath(riverPath, color = Color(0xFF102027))

      // Satellite Roads in crisp white/amber
      val hStreets = listOf(h * 0.22f, h * 0.48f, h * 0.76f)
      hStreets.forEach { y ->
        drawLine(Color(0xFF455A64), Offset(0f, y), Offset(w, y), strokeWidth = 18f * zoom)
        drawLine(Color(0xFFCFD8DC), Offset(0f, y), Offset(w, y), strokeWidth = 12f * zoom)
      }
      val vStreets = listOf(w * 0.18f, w * 0.48f, w * 0.82f)
      vStreets.forEach { x ->
        drawLine(Color(0xFF455A64), Offset(x, 0f), Offset(x, h), strokeWidth = 18f * zoom)
        drawLine(Color(0xFFCFD8DC), Offset(x, 0f), Offset(x, h), strokeWidth = 12f * zoom)
      }
    }

    MapThemeType.TERRAIN -> {
      // Topographic terrain with contour tint
      drawRect(Color(0xFFE8E0D4))

      drawRect(Color(0xFFD4E0C8), topLeft = Offset(0f, 0f), size = Size(w * 0.4f, h * 0.4f))
      drawRect(Color(0xFFC2D6B2), topLeft = Offset(w * 0.5f, h * 0.5f), size = Size(w * 0.5f, h * 0.5f))

      val hStreets = listOf(h * 0.22f, h * 0.48f, h * 0.76f)
      hStreets.forEach { y ->
        drawLine(Color(0xFFC7BAA7), Offset(0f, y), Offset(w, y), strokeWidth = 20f * zoom)
        drawLine(Color(0xFFFAF6F0), Offset(0f, y), Offset(w, y), strokeWidth = 14f * zoom)
      }
      val vStreets = listOf(w * 0.18f, w * 0.48f, w * 0.82f)
      vStreets.forEach { x ->
        drawLine(Color(0xFFC7BAA7), Offset(x, 0f), Offset(x, h), strokeWidth = 20f * zoom)
        drawLine(Color(0xFFFAF6F0), Offset(x, 0f), Offset(x, h), strokeWidth = 14f * zoom)
      }
    }
  }
}
