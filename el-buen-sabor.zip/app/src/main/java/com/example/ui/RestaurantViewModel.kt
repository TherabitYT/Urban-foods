package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RestaurantDatabase
import com.example.data.RestaurantRepository
import com.example.model.AdminAuth
import com.example.model.AppNotificationItem
import com.example.model.CartItem
import com.example.model.DeliveryAddress
import com.example.model.ExtraOption
import com.example.model.FoodCategory
import com.example.model.MenuCatalog
import com.example.model.MenuItem
import com.example.model.NotificationCategory
import com.example.model.OrderItemRecord
import com.example.model.OrderStatus
import com.example.model.RestaurantOrder
import com.example.model.SideOption
import com.example.model.SpiceLevel
import com.example.model.UserProfile
import com.example.util.NotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppTab(val title: String, val iconText: String) {
  MENU("Menú", "🍽️"),
  TRACKING("En Camino", "🛵"),
  HISTORY("Historial", "📜")
}

data class ChatMessage(
  val sender: String,
  val text: String,
  val time: String,
  val isFromCustomer: Boolean
)

class RestaurantViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: RestaurantRepository

  init {
    val db = RestaurantDatabase.getDatabase(application)
    repository = RestaurantRepository(db.restaurantDao())
    repository.initializeSeedDataIfEmpty(viewModelScope)
    NotificationHelper.createNotificationChannels(application)
  }

  // Navigation tab
  private val _currentTab = MutableStateFlow(AppTab.MENU)
  val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

  fun setTab(tab: AppTab) {
    _currentTab.value = tab
  }

  // User Profile & Google Sign-In
  private val _userProfile = MutableStateFlow(UserProfile.GoogleUserDefault)
  val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

  private val _isProfileDialogOpen = MutableStateFlow(false)
  val isProfileDialogOpen: StateFlow<Boolean> = _isProfileDialogOpen.asStateFlow()

  fun openProfileDialog() {
    _isProfileDialogOpen.value = true
  }

  fun closeProfileDialog() {
    _isProfileDialogOpen.value = false
  }

  fun signInWithGoogle(name: String = "Carlos Raúl", email: String = "carlosraul185@gmail.com") {
    _userProfile.value = UserProfile(
      id = "google_user_${System.currentTimeMillis()}",
      name = name,
      email = email,
      avatarUrl = null,
      isSignedInWithGoogle = true,
      phoneNumber = "+57 301 555 7890"
    )
    addNotification(
      title = "¡Bienvenido a El Buen Sabor!",
      message = "Has iniciado sesión con tu cuenta de Google ($email).",
      category = NotificationCategory.SISTEMA
    )
    _isProfileDialogOpen.value = false
  }

  fun signOutGoogle() {
    _userProfile.value = UserProfile(
      id = "guest_${System.currentTimeMillis()}",
      name = "Invitado",
      email = "",
      avatarUrl = null,
      isSignedInWithGoogle = false
    )
    _isProfileDialogOpen.value = false
  }

  // Admin Mode & Master Password (Google123@@)
  private val _isAdminAuthenticated = MutableStateFlow(false)
  val isAdminAuthenticated: StateFlow<Boolean> = _isAdminAuthenticated.asStateFlow()

  private val _isAdminDialogOpen = MutableStateFlow(false)
  val isAdminDialogOpen: StateFlow<Boolean> = _isAdminDialogOpen.asStateFlow()

  private val _adminPasswordError = MutableStateFlow<String?>(null)
  val adminPasswordError: StateFlow<String?> = _adminPasswordError.asStateFlow()

  fun openAdminDialog() {
    _adminPasswordError.value = null
    _isAdminDialogOpen.value = true
  }

  fun closeAdminDialog() {
    _isAdminDialogOpen.value = false
    _adminPasswordError.value = null
  }

  fun verifyAndLoginAdmin(inputKey: String): Boolean {
    if (AdminAuth.verifyKey(inputKey)) {
      _isAdminAuthenticated.value = true
      _isAdminDialogOpen.value = false
      _adminPasswordError.value = null
      return true
    } else {
      _adminPasswordError.value = "Clave de acceso incorrecta. Verifique e intente nuevamente."
      return false
    }
  }

  fun exitAdminMode() {
    _isAdminAuthenticated.value = false
  }

  // Categories & Search
  private val _selectedCategory = MutableStateFlow(FoodCategory.TODOS)
  val selectedCategory: StateFlow<FoodCategory> = _selectedCategory.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  fun setCategory(category: FoodCategory) {
    _selectedCategory.value = category
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  // Dynamic Menu (Catalog + Admin Added Dishes + Overrides)
  val customDishes: StateFlow<List<MenuItem>> = repository.customMenuItems
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _menuOverrides = MutableStateFlow<Map<String, MenuItem>>(emptyMap())

  val allDishes: StateFlow<List<MenuItem>> = combine(
    repository.customMenuItems,
    _menuOverrides,
    _selectedCategory,
    _searchQuery
  ) { customList, overrides, category, query ->
    val merged = LinkedHashMap<String, MenuItem>()
    // 1. Initial base items
    MenuCatalog.allItems.forEach { merged[it.id] = it }
    // 2. Room stored custom & edited dishes
    customList.forEach { merged[it.id] = it }
    // 3. Fast in-memory overrides
    overrides.forEach { (id, item) -> merged[id] = item }

    merged.values.filter { item ->
      val matchesCategory = (category == FoodCategory.TODOS || item.category == category)
      val matchesQuery = query.isBlank() ||
        item.name.contains(query, ignoreCase = true) ||
        item.description.contains(query, ignoreCase = true) ||
        item.ingredients.any { it.contains(query, ignoreCase = true) }
      matchesCategory && matchesQuery
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MenuCatalog.allItems)

  // Dish customization dialog
  private val _selectedDishForCustomization = MutableStateFlow<MenuItem?>(null)
  val selectedDishForCustomization: StateFlow<MenuItem?> = _selectedDishForCustomization.asStateFlow()

  fun openDishDetail(item: MenuItem) {
    _selectedDishForCustomization.value = item
  }

  fun closeDishDetail() {
    _selectedDishForCustomization.value = null
  }

  // Cart Management
  private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
  val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

  private val _isCartOpen = MutableStateFlow(false)
  val isCartOpen: StateFlow<Boolean> = _isCartOpen.asStateFlow()

  fun openCart() {
    _isCartOpen.value = true
  }

  fun closeCart() {
    _isCartOpen.value = false
  }

  fun addToCart(
    item: MenuItem,
    quantity: Int,
    spiceLevel: SpiceLevel? = null,
    side: SideOption? = null,
    extras: List<ExtraOption> = emptyList(),
    notes: String = ""
  ) {
    val newItem = CartItem(
      id = UUID.randomUUID().toString(),
      menuItem = item,
      quantity = quantity,
      selectedSpiceLevel = spiceLevel,
      selectedSide = side,
      selectedExtras = extras,
      specialInstructions = notes
    )
    _cartItems.value = _cartItems.value + newItem
    closeDishDetail()
  }

  fun updateCartQuantity(cartItemId: String, delta: Int) {
    val current = _cartItems.value
    val updated = current.mapNotNull { item ->
      if (item.id == cartItemId) {
        val newQty = item.quantity + delta
        if (newQty > 0) item.copy(quantity = newQty) else null
      } else {
        item
      }
    }
    _cartItems.value = updated
  }

  fun removeCartItem(cartItemId: String) {
    _cartItems.value = _cartItems.value.filterNot { it.id == cartItemId }
  }

  fun clearCart() {
    _cartItems.value = emptyList()
  }

  // Addresses
  val savedAddresses: StateFlow<List<DeliveryAddress>> = repository.savedAddresses
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _selectedAddress = MutableStateFlow<DeliveryAddress?>(null)
  val selectedAddress: StateFlow<DeliveryAddress?> = _selectedAddress.asStateFlow()

  private val _isAddressDialogOpen = MutableStateFlow(false)
  val isAddressDialogOpen: StateFlow<Boolean> = _isAddressDialogOpen.asStateFlow()

  fun openAddressDialog() {
    _isAddressDialogOpen.value = true
  }

  fun closeAddressDialog() {
    _isAddressDialogOpen.value = false
  }

  fun selectAddress(address: DeliveryAddress) {
    _selectedAddress.value = address
  }

  fun saveNewAddress(
    label: String,
    street: String,
    number: String,
    neighborhood: String,
    reference: String,
    phone: String,
    setAsDefault: Boolean,
    latitude: Double = 6.2442,
    longitude: Double = -75.5812
  ) {
    viewModelScope.launch {
      val newAddress = DeliveryAddress(
        id = 0,
        label = label.ifBlank { "Casa" },
        street = street,
        numberOrApartment = number,
        neighborhood = neighborhood,
        reference = reference,
        phone = phone,
        isDefault = setAsDefault,
        latitude = latitude,
        longitude = longitude
      )
      repository.saveAddress(newAddress)
      _selectedAddress.value = newAddress
      _isAddressDialogOpen.value = false
    }
  }

  // Orders flow
  val allOrders: StateFlow<List<RestaurantOrder>> = repository.allOrders
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val activeOrder: StateFlow<RestaurantOrder?> = repository.activeOrder
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  // Push Notifications History
  private val _notificationHistory = MutableStateFlow<List<AppNotificationItem>>(
    listOf(
      AppNotificationItem(
        id = "notif_promo_init",
        title = "🔥 ¡Bienvenido a El Buen Sabor!",
        message = "Disfruta de nuestros combos especiales de Arroz Chino, Tacos al Pastor, Burgers y Perros Calientes.",
        category = NotificationCategory.PROMOCION
      )
    )
  )
  val notificationHistory: StateFlow<List<AppNotificationItem>> = _notificationHistory.asStateFlow()

  fun addNotification(title: String, message: String, category: NotificationCategory, orderId: String? = null) {
    val item = AppNotificationItem(
      id = UUID.randomUUID().toString(),
      title = title,
      message = message,
      timestamp = System.currentTimeMillis(),
      category = category,
      relatedOrderId = orderId
    )
    _notificationHistory.value = listOf(item) + _notificationHistory.value
  }

  // Driver Chat
  private val _driverChatMessages = MutableStateFlow<List<ChatMessage>>(
    listOf(
      ChatMessage("Carlos (Repartidor)", "¡Hola! Estoy atento a tu pedido en El Buen Sabor.", "12:00 PM", false)
    )
  )
  val driverChatMessages: StateFlow<List<ChatMessage>> = _driverChatMessages.asStateFlow()

  private val _isChatDialogOpen = MutableStateFlow(false)
  val isChatDialogOpen: StateFlow<Boolean> = _isChatDialogOpen.asStateFlow()

  fun openChatDialog() {
    _isChatDialogOpen.value = true
  }

  fun closeChatDialog() {
    _isChatDialogOpen.value = false
  }

  fun sendCustomerMessage(text: String) {
    if (text.isBlank()) return
    val userMsg = ChatMessage("Tú", text, "Ahora", true)
    _driverChatMessages.value = _driverChatMessages.value + userMsg

    viewModelScope.launch {
      delay(1200)
      val replyText = when {
        text.contains("donde", ignoreCase = true) || text.contains("dónde", ignoreCase = true) ->
          "Ya recogí la comida calientita en el restaurante. Voy en la moto a unas 4 cuadras, llego en 5 minutos."
        text.contains("timbre", ignoreCase = true) || text.contains("puerta", ignoreCase = true) ->
          "Entendido, toco el timbre en cuanto esté frente a la casa."
        text.contains("cambio", ignoreCase = true) || text.contains("pago", ignoreCase = true) ->
          "Perfecto, traigo cambio exacto para tu entrega."
        else ->
          "¡Recibido con gusto! Estoy cuidando que tu pedido llegue en perfecto estado."
      }
      _driverChatMessages.value = _driverChatMessages.value + ChatMessage("Carlos (Repartidor)", replyText, "Ahora", false)
    }
  }

  // Checkout order
  private var simulationJob: Job? = null

  fun checkoutOrder(paymentMethod: String) {
    val items = _cartItems.value
    if (items.isEmpty()) return

    val currentAddress = _selectedAddress.value
      ?: savedAddresses.value.firstOrNull { it.isDefault }
      ?: savedAddresses.value.firstOrNull()
      ?: DeliveryAddress(
        label = "Casa",
        street = "Calle 45 # 18-32",
        numberOrApartment = "Apto 302",
        neighborhood = "La Floresta",
        reference = "Tocar timbre 302",
        phone = "+57 301 555 7890"
      )

    val subtotal = items.sumOf { it.totalPrice }
    val deliveryFee = 2.50
    val total = subtotal + deliveryFee
    val orderId = "ORD-${(1000..9999).random()}"

    val recordItems = items.map { cartItem ->
      val extrasSummaryList = mutableListOf<String>()
      cartItem.selectedSpiceLevel?.let { extrasSummaryList.add("${it.icon} ${it.name}") }
      cartItem.selectedSide?.let { if (it.name != "Sin Guarnición") extrasSummaryList.add("🍟 ${it.name}") }
      cartItem.selectedExtras.forEach { extrasSummaryList.add(it.name) }

      OrderItemRecord(
        menuItemId = cartItem.menuItem.id,
        menuItemName = cartItem.menuItem.name,
        categoryName = cartItem.menuItem.category.displayName,
        unitPrice = cartItem.unitPrice,
        quantity = cartItem.quantity,
        selectedExtrasSummary = extrasSummaryList.joinToString(", "),
        specialInstructions = cartItem.specialInstructions
      )
    }

    val newOrder = RestaurantOrder(
      id = orderId,
      timestamp = System.currentTimeMillis(),
      status = OrderStatus.CONFIRMADO,
      address = currentAddress,
      items = recordItems,
      subtotal = subtotal,
      deliveryFee = deliveryFee,
      total = total,
      paymentMethod = paymentMethod,
      estimatedMinutesRemaining = 25,
      driverName = "Carlos Mendoza",
      driverPhone = "+57 312 884 9201",
      driverPlate = "MOTO-782",
      deliveryProgressPercent = 0.15f
    )

    viewModelScope.launch {
      repository.insertOrder(newOrder)
      clearCart()
      closeCart()
      _currentTab.value = AppTab.TRACKING

      // Send immediate Push Notification for Confirmation
      NotificationHelper.sendOrderStatusNotification(
        getApplication(),
        orderId,
        OrderStatus.CONFIRMADO
      )
      addNotification(
        title = "✅ Pedido Confirmado • $orderId",
        message = "El restaurante ha recibido tu pedido de ${recordItems.size} platos. ¡Comenzamos a preparar!",
        category = NotificationCategory.PEDIDO,
        orderId = orderId
      )

      startLiveOrderSimulation(orderId)
    }
  }

  // Simulation of live order tracking with native push notifications
  private fun startLiveOrderSimulation(orderId: String) {
    simulationJob?.cancel()
    simulationJob = viewModelScope.launch {
      // 1. CONFIRMADO -> Wait and move to EN_PREPARACION
      delay(9000)
      repository.updateOrderStatus(orderId, OrderStatus.EN_PREPARACION, 18, 0.45f)
      NotificationHelper.sendOrderStatusNotification(
        getApplication(),
        orderId,
        OrderStatus.EN_PREPARACION
      )
      addNotification(
        title = "👨‍🍳 ¡En Cocina! • $orderId",
        message = "Tu comida está en los woks y en las brasas. Nuestros chefs están preparando todo calientito.",
        category = NotificationCategory.PEDIDO,
        orderId = orderId
      )

      // 2. EN_PREPARACION -> Wait and move to EN_CAMINO
      delay(12000)
      repository.updateOrderStatus(orderId, OrderStatus.EN_CAMINO, 10, 0.70f)
      NotificationHelper.sendOrderStatusNotification(
        getApplication(),
        orderId,
        OrderStatus.EN_CAMINO
      )
      addNotification(
        title = "🛵 ¡En Camino! • $orderId",
        message = "El repartidor Carlos (MOTO-782) lleva tu comida rumbo a tu dirección.",
        category = NotificationCategory.PEDIDO,
        orderId = orderId
      )

      // 3. EN_CAMINO -> Moving closer
      delay(10000)
      repository.updateOrderStatus(orderId, OrderStatus.EN_CAMINO, 3, 0.90f)

      // 4. ENTREGADO
      delay(10000)
      repository.updateOrderStatus(orderId, OrderStatus.ENTREGADO, 0, 1.0f)
      NotificationHelper.sendOrderStatusNotification(
        getApplication(),
        orderId,
        OrderStatus.ENTREGADO
      )
      addNotification(
        title = "🎉 ¡Pedido Entregado! • $orderId",
        message = "¡Tu pedido ha sido entregado exitosamente! Muchas gracias por preferir El Buen Sabor.",
        category = NotificationCategory.PEDIDO,
        orderId = orderId
      )
    }
  }

  fun advanceSimulationStepManually() {
    val current = activeOrder.value ?: return
    viewModelScope.launch {
      when (current.status) {
        OrderStatus.CONFIRMADO -> {
          repository.updateOrderStatus(current.id, OrderStatus.EN_PREPARACION, 18, 0.45f)
          NotificationHelper.sendOrderStatusNotification(getApplication(), current.id, OrderStatus.EN_PREPARACION)
        }
        OrderStatus.EN_PREPARACION -> {
          repository.updateOrderStatus(current.id, OrderStatus.EN_CAMINO, 10, 0.75f)
          NotificationHelper.sendOrderStatusNotification(getApplication(), current.id, OrderStatus.EN_CAMINO)
        }
        OrderStatus.EN_CAMINO -> {
          repository.updateOrderStatus(current.id, OrderStatus.ENTREGADO, 0, 1.0f)
          NotificationHelper.sendOrderStatusNotification(getApplication(), current.id, OrderStatus.ENTREGADO)
        }
        OrderStatus.ENTREGADO -> {}
      }
    }
  }

  // Reorder past order
  fun reorderPastOrder(order: RestaurantOrder, directCheckout: Boolean = false) {
    val newCartItems = order.items.mapNotNull { record ->
      val menuItem = MenuCatalog.getItemById(record.menuItemId)
        ?: allDishes.value.firstOrNull { it.id == record.menuItemId || it.name == record.menuItemName }
      if (menuItem != null) {
        val extras = record.selectedExtrasSummary.split(", ")
          .filter { it.isNotBlank() && !it.contains("Picante") && !it.contains("Guarnición") }
          .map { ExtraOption(UUID.randomUUID().toString(), it, 1.0) }
        CartItem(
          id = UUID.randomUUID().toString(),
          menuItem = menuItem,
          quantity = record.quantity,
          selectedSpiceLevel = menuItem.availableSpiceLevels.firstOrNull(),
          selectedSide = menuItem.availableSides.firstOrNull(),
          selectedExtras = extras,
          specialInstructions = record.specialInstructions
        )
      } else null
    }

    _cartItems.value = newCartItems
    _selectedAddress.value = order.address

    if (directCheckout && newCartItems.isNotEmpty()) {
      checkoutOrder(order.paymentMethod)
    } else {
      _currentTab.value = AppTab.MENU
      _isCartOpen.value = true
    }
  }

  // ================= ADMIN DASHBOARD FUNCTIONS =================

  fun adminUpdateOrderStatus(orderId: String, newStatus: OrderStatus) {
    viewModelScope.launch {
      val (mins, progress) = when (newStatus) {
        OrderStatus.CONFIRMADO -> Pair(25, 0.15f)
        OrderStatus.EN_PREPARACION -> Pair(15, 0.45f)
        OrderStatus.EN_CAMINO -> Pair(8, 0.75f)
        OrderStatus.ENTREGADO -> Pair(0, 1.0f)
      }
      repository.updateOrderStatus(orderId, newStatus, mins, progress)

      // Send push notification to user device
      NotificationHelper.sendOrderStatusNotification(
        getApplication(),
        orderId,
        newStatus
      )

      val statusMsg = when (newStatus) {
        OrderStatus.CONFIRMADO -> "El pedido ha sido confirmado por la gerencia del restaurante."
        OrderStatus.EN_PREPARACION -> "¡Tu pedido está en cocina! Los woks y parrillas están en acción."
        OrderStatus.EN_CAMINO -> "¡Repartidor asignado! Carlos va en camino con tu comida."
        OrderStatus.ENTREGADO -> "¡Pedido marcado como entregado! ¡Buen provecho!"
      }

      addNotification(
        title = "Actualización de Orden • $orderId",
        message = statusMsg,
        category = NotificationCategory.PEDIDO,
        orderId = orderId
      )
    }
  }

  fun adminDeleteOrder(orderId: String) {
    viewModelScope.launch {
      repository.deleteOrder(orderId)
    }
  }

  fun adminAddNewMenuItem(
    name: String,
    category: FoodCategory,
    description: String,
    price: Double,
    prepTime: String,
    ingredients: List<String>,
    badge: String?
  ) {
    val newDish = MenuItem(
      id = "dish_${System.currentTimeMillis()}",
      name = name,
      category = category,
      description = description,
      price = price,
      badge = badge ?: "Nuevo",
      preparationTime = prepTime.ifBlank { "15-20 min" },
      ingredients = ingredients,
      availableExtras = listOf(
        ExtraOption("ext_queso", "Queso Fundido Extra", 1.25),
        ExtraOption("ext_bacon", "Tocineta Crujiente", 1.50),
        ExtraOption("ext_salsa", "Salsa Especial de la Casa", 0.75)
      ),
      availableSides = MenuCatalog.standardSides,
      availableSpiceLevels = MenuCatalog.standardSpiceLevels,
      isAvailable = true
    )

    viewModelScope.launch {
      repository.insertCustomMenuItem(newDish)
      addNotification(
        title = "🍽️ ¡Nuevo Plato en Carta!",
        message = "Se ha agregado '${newDish.name}' al menú de El Buen Sabor.",
        category = NotificationCategory.PROMOCION
      )
    }
  }

  fun adminSaveOrUpdateMenuItem(item: MenuItem) {
    val updatedMap = _menuOverrides.value.toMutableMap()
    updatedMap[item.id] = item
    _menuOverrides.value = updatedMap

    viewModelScope.launch {
      repository.insertCustomMenuItem(item)
      addNotification(
        title = "Plato Actualizado: ${item.name}",
        message = "Precios, opciones e imagen modificados por el administrador.",
        category = NotificationCategory.SISTEMA
      )
    }
  }

  fun adminToggleDishAvailability(dishId: String, isAvailable: Boolean) {
    viewModelScope.launch {
      repository.updateCustomMenuItemAvailability(dishId, isAvailable)
    }
  }

  fun adminDeleteCustomDish(dishId: String) {
    viewModelScope.launch {
      repository.deleteCustomMenuItem(dishId)
    }
  }

  fun adminBroadcastPromotion(title: String, message: String) {
    NotificationHelper.sendPromotionNotification(
      getApplication(),
      title,
      message
    )
    addNotification(
      title = title,
      message = message,
      category = NotificationCategory.PROMOCION
    )
  }
}
