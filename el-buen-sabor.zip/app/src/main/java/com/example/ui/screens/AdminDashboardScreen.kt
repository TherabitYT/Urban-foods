package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OutdoorGrill
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppNotificationItem
import com.example.model.FoodCategory
import com.example.model.MenuItem
import com.example.model.OrderStatus
import com.example.model.RestaurantOrder
import java.util.Locale

enum class AdminTab(val title: String, val icon: String) {
  ORDERS("Órdenes en Vivo", "📋"),
  MENU("Gestor del Menú", "🍽️"),
  PROMOS("Difusión Push", "📢"),
  METRICS("Métricas", "📊")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
  orders: List<RestaurantOrder>,
  allDishes: List<MenuItem>,
  notifications: List<AppNotificationItem>,
  onUpdateOrderStatus: (orderId: String, newStatus: OrderStatus) -> Unit,
  onDeleteOrder: (orderId: String) -> Unit,
  onAddNewDish: (
    name: String,
    category: FoodCategory,
    description: String,
    price: Double,
    prepTime: String,
    ingredients: List<String>,
    badge: String?
  ) -> Unit,
  onToggleDishAvailability: (dishId: String, isAvailable: Boolean) -> Unit,
  onDeleteDish: (dishId: String) -> Unit,
  onBroadcastPromo: (title: String, message: String) -> Unit,
  onExitAdmin: () -> Unit,
  onSaveOrUpdateDish: (MenuItem) -> Unit = {}
) {
  var selectedTab by remember { mutableStateOf(AdminTab.ORDERS) }
  val context = LocalContext.current

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "Panel de Administración",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Restaurante El Buen Sabor • Clave Maestra Activa",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = onExitAdmin, modifier = Modifier.testTag("exit_admin_button")) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Regresar al modo cliente")
          }
        },
        actions = {
          OutlinedButton(
            onClick = onExitAdmin,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.padding(end = 8.dp)
          ) {
            Text("Salir Admin", style = MaterialTheme.typography.labelSmall)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer,
          titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
      )
    }
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      // Admin Tabs
      ScrollableTabRow(
        selectedTabIndex = selectedTab.ordinal,
        edgePadding = 16.dp,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary,
        indicator = { tabPositions ->
          TabRowDefaults.SecondaryIndicator(
            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
            color = MaterialTheme.colorScheme.primary
          )
        }
      ) {
        AdminTab.entries.forEach { tab ->
          Tab(
            selected = selectedTab == tab,
            onClick = { selectedTab = tab },
            text = {
              Text(
                text = "${tab.icon} ${tab.title}",
                fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                style = MaterialTheme.typography.labelLarge
              )
            },
            modifier = Modifier.testTag("admin_tab_${tab.name}")
          )
        }
      }

      Box(modifier = Modifier.fillMaxSize()) {
        when (selectedTab) {
          AdminTab.ORDERS -> {
            AdminOrdersView(
              orders = orders,
              onUpdateOrderStatus = onUpdateOrderStatus,
              onDeleteOrder = onDeleteOrder
            )
          }
          AdminTab.MENU -> {
            AdminMenuView(
              allDishes = allDishes,
              onAddNewDish = onAddNewDish,
              onToggleDishAvailability = onToggleDishAvailability,
              onDeleteDish = onDeleteDish,
              onSaveOrUpdateDish = onSaveOrUpdateDish
            )
          }
          AdminTab.PROMOS -> {
            AdminPushNotificationView(
              notifications = notifications,
              onBroadcastPromo = { title, msg ->
                onBroadcastPromo(title, msg)
                Toast.makeText(context, "¡Notificación push emitida a los clientes!", Toast.LENGTH_SHORT).show()
              }
            )
          }
          AdminTab.METRICS -> {
            AdminMetricsView(orders = orders, dishes = allDishes)
          }
        }
      }
    }
  }
}

// ---------------- 1. ADMIN ORDERS VIEW ----------------
@Composable
fun AdminOrdersView(
  orders: List<RestaurantOrder>,
  onUpdateOrderStatus: (orderId: String, newStatus: OrderStatus) -> Unit,
  onDeleteOrder: (orderId: String) -> Unit
) {
  if (orders.isEmpty()) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "📋", fontSize = 48.sp)
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "No hay órdenes registradas",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "Las nuevas órdenes que los clientes hagan aparecerán aquí en tiempo real.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  } else {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Total: ${orders.size} órdenes recibidas",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(
              text = "En proceso: ${orders.count { it.status != OrderStatus.ENTREGADO }}",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
          }
        }
      }

      items(orders, key = { it.id }) { order ->
        AdminOrderCard(
          order = order,
          onUpdateOrderStatus = onUpdateOrderStatus,
          onDeleteOrder = onDeleteOrder
        )
      }
    }
  }
}

@Composable
fun AdminOrderCard(
  order: RestaurantOrder,
  onUpdateOrderStatus: (orderId: String, newStatus: OrderStatus) -> Unit,
  onDeleteOrder: (orderId: String) -> Unit
) {
  val (badgeColor, textColor) = when (order.status) {
    OrderStatus.CONFIRMADO -> Pair(Color(0xFFE0F2FE), Color(0xFF0369A1))
    OrderStatus.EN_PREPARACION -> Pair(Color(0xFFFEF3C7), Color(0xFFB45309))
    OrderStatus.EN_CAMINO -> Pair(Color(0xFFEDE9FE), Color(0xFF6D28D9))
    OrderStatus.ENTREGADO -> Pair(Color(0xFFDCFCE7), Color(0xFF15803D))
  }

  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
    shape = RoundedCornerShape(16.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("admin_order_card_${order.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Header row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = order.id,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = order.address.fullDisplayAddress,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Surface(
          color = badgeColor,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            text = order.status.title,
            color = textColor,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Customer contact & Payment
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "Tel: ${order.address.phone}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = "Pago: ${order.paymentMethod}",
          style = MaterialTheme.typography.bodySmall,
          fontWeight = FontWeight.Medium
        )
      }

      HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

      // Items summary
      Text(
        text = "Platos ordenados:",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(4.dp))
      order.items.forEach { item ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "${item.quantity}x ${item.menuItemName}",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold
            )
            if (item.selectedExtrasSummary.isNotBlank()) {
              Text(
                text = "• ${item.selectedExtrasSummary}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
              )
            }
            if (item.specialInstructions.isNotBlank()) {
              Text(
                text = "Nota: ${item.specialInstructions}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error
              )
            }
          }
          Text(
            text = String.format(Locale.US, "$%.2f", item.subtotal),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(text = "Total con Delivery:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(
          text = String.format(Locale.US, "$%.2f", order.total),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.ExtraBold,
          color = MaterialTheme.colorScheme.primary
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action buttons to advance order & push notification
      Text(
        text = "Cambiar Estado (Alerta Push Automática):",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedButton(
          onClick = { onUpdateOrderStatus(order.id, OrderStatus.EN_PREPARACION) },
          enabled = order.status != OrderStatus.EN_PREPARACION && order.status != OrderStatus.ENTREGADO,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f).testTag("order_to_kitchen_${order.id}")
        ) {
          Text("👨‍🍳 Cocina", fontSize = 12.sp)
        }

        OutlinedButton(
          onClick = { onUpdateOrderStatus(order.id, OrderStatus.EN_CAMINO) },
          enabled = order.status != OrderStatus.EN_CAMINO && order.status != OrderStatus.ENTREGADO,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f).testTag("order_to_dispatch_${order.id}")
        ) {
          Text("🛵 Enviar", fontSize = 12.sp)
        }

        Button(
          onClick = { onUpdateOrderStatus(order.id, OrderStatus.ENTREGADO) },
          enabled = order.status != OrderStatus.ENTREGADO,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.weight(1f).testTag("order_to_delivered_${order.id}")
        ) {
          Text("✅ Entregar", fontSize = 12.sp)
        }

        IconButton(
          onClick = { onDeleteOrder(order.id) },
          modifier = Modifier.size(36.dp).testTag("delete_order_${order.id}")
        ) {
          Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
        }
      }
    }
  }
}

// ---------------- 2. ADMIN MENU VIEW (ADD & MANAGE DISHES) ----------------
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AdminMenuView(
  allDishes: List<MenuItem>,
  onAddNewDish: (
    name: String,
    category: FoodCategory,
    description: String,
    price: Double,
    prepTime: String,
    ingredients: List<String>,
    badge: String?
  ) -> Unit,
  onToggleDishAvailability: (dishId: String, isAvailable: Boolean) -> Unit,
  onDeleteDish: (dishId: String) -> Unit,
  onSaveOrUpdateDish: (MenuItem) -> Unit = {}
) {
  val context = LocalContext.current
  var isAddFormExpanded by remember { mutableStateOf(false) }
  var editingDish by remember { mutableStateOf<MenuItem?>(null) }

  if (editingDish != null) {
    com.example.ui.components.AdminDishEditorDialog(
      dish = editingDish!!,
      onSaveDish = {
        onSaveOrUpdateDish(it)
        editingDish = null
      },
      onDismiss = { editingDish = null }
    )
  }

  // New Dish Form States
  var dishName by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(FoodCategory.HAMBURGUESAS) }
  var description by remember { mutableStateOf("") }
  var priceInput by remember { mutableStateOf("") }
  var prepTime by remember { mutableStateOf("15-20 min") }
  var ingredientsInput by remember { mutableStateOf("") }
  var badgeInput by remember { mutableStateOf("Especial del Chef") }
  var isCategoryDropdownOpen by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Add Dish Accordion Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().testTag("admin_add_dish_card")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Agregar Nuevo Platillo al Menú",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
            }
            IconButton(onClick = { isAddFormExpanded = !isAddFormExpanded }) {
              Icon(
                imageVector = if (isAddFormExpanded) Icons.Default.Close else Icons.Default.Add,
                contentDescription = null
              )
            }
          }

          if (isAddFormExpanded) {
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
              value = dishName,
              onValueChange = { dishName = it },
              label = { Text("Nombre del Platillo *") },
              placeholder = { Text("Ej: Arroz Especial Cantonés") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth().testTag("input_dish_name")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Category selector
            ExposedDropdownMenuBox(
              expanded = isCategoryDropdownOpen,
              onExpandedChange = { isCategoryDropdownOpen = !isCategoryDropdownOpen }
            ) {
              OutlinedTextField(
                value = "${selectedCategory.iconText} ${selectedCategory.displayName}",
                onValueChange = {},
                readOnly = true,
                label = { Text("Categoría *") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCategoryDropdownOpen) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
              )
              ExposedDropdownMenu(
                expanded = isCategoryDropdownOpen,
                onDismissRequest = { isCategoryDropdownOpen = false }
              ) {
                FoodCategory.entries.filter { it != FoodCategory.TODOS }.forEach { cat ->
                  DropdownMenuItem(
                    text = { Text("${cat.iconText} ${cat.displayName}") },
                    onClick = {
                      selectedCategory = cat
                      isCategoryDropdownOpen = false
                    }
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = description,
              onValueChange = { description = it },
              label = { Text("Descripción Detallada *") },
              placeholder = { Text("Describe los sabores, técnica de cocción, etc.") },
              maxLines = 3,
              modifier = Modifier.fillMaxWidth().testTag("input_dish_description")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedTextField(
                value = priceInput,
                onValueChange = { priceInput = it },
                label = { Text("Precio Base ($) *") },
                placeholder = { Text("8.50") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_dish_price")
              )

              OutlinedTextField(
                value = prepTime,
                onValueChange = { prepTime = it },
                label = { Text("Tiempo Prep.") },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("input_dish_preptime")
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = ingredientsInput,
              onValueChange = { ingredientsInput = it },
              label = { Text("Ingredientes (separados por coma)") },
              placeholder = { Text("Pollo, camarón, cebollín, tortilla de huevo") },
              modifier = Modifier.fillMaxWidth().testTag("input_dish_ingredients")
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
              value = badgeInput,
              onValueChange = { badgeInput = it },
              label = { Text("Etiqueta / Badge (Opcional)") },
              placeholder = { Text("Ej: Especial del Chef, 2x1, Top 1") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
              onClick = {
                val parsedPrice = priceInput.toDoubleOrNull()
                if (dishName.isNotBlank() && parsedPrice != null && description.isNotBlank()) {
                  val ingList = ingredientsInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                  onAddNewDish(
                    dishName,
                    selectedCategory,
                    description,
                    parsedPrice,
                    prepTime,
                    ingList,
                    badgeInput.ifBlank { null }
                  )
                  Toast.makeText(context, "¡Platillo '$dishName' agregado al menú!", Toast.LENGTH_SHORT).show()
                  // Reset form
                  dishName = ""
                  description = ""
                  priceInput = ""
                  ingredientsInput = ""
                  isAddFormExpanded = false
                } else {
                  Toast.makeText(context, "Por favor completa nombre, precio válido y descripción.", Toast.LENGTH_SHORT).show()
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("submit_new_dish_button")
            ) {
              Text("Guardar y Publicar en el Menú", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Platos de la Carta (${allDishes.size})",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "Activar o pausar según inventario",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Dish items list
    items(allDishes, key = { it.id }) { dish ->
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_dish_item_${dish.id}")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Dish Image Thumbnail
            Box(
              modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black.copy(alpha = 0.05f))
            ) {
              if (!dish.customImageUrl.isNullOrBlank()) {
                coil.compose.AsyncImage(
                  model = dish.customImageUrl,
                  contentDescription = dish.name,
                  placeholder = androidx.compose.ui.res.painterResource(id = dish.imageRes),
                  error = androidx.compose.ui.res.painterResource(id = dish.imageRes),
                  contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
              } else {
                androidx.compose.foundation.Image(
                  painter = androidx.compose.ui.res.painterResource(id = dish.imageRes),
                  contentDescription = dish.name,
                  contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
              }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = dish.name,
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.Bold
                )
                if (dish.badge != null) {
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(4.dp)
                  ) {
                    Text(
                      text = dish.badge,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.primary,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                  }
                }
              }
              Text(
                text = "${dish.category.displayName} • ${String.format(Locale.US, "$%.2f", dish.price)}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${dish.availableExtras.size} extras • ${dish.availableSides.size} guarniciones",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = if (dish.isAvailable) "✓ Disponible en app" else "✗ Pausado",
                style = MaterialTheme.typography.labelSmall,
                color = if (dish.isAvailable) Color(0xFF15803D) else MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.SemiBold
              )
            }

            Column(horizontalAlignment = Alignment.End) {
              Switch(
                checked = dish.isAvailable,
                onCheckedChange = { onToggleDishAvailability(dish.id, it) },
                colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("toggle_dish_${dish.id}")
              )
              if (dish.id.startsWith("dish_")) {
                IconButton(onClick = { onDeleteDish(dish.id) }, modifier = Modifier.size(28.dp)) {
                  Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Edit Dish Button
          Button(
            onClick = { editingDish = dish },
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.primaryContainer,
              contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(38.dp)
              .testTag("edit_dish_btn_${dish.id}")
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Modificar Imagen, Precios y Opciones",
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }
    }
  }
}

// ---------------- 3. ADMIN PUSH & PROMOTIONS VIEW ----------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminPushNotificationView(
  notifications: List<AppNotificationItem>,
  onBroadcastPromo: (title: String, message: String) -> Unit
) {
  var promoTitle by remember { mutableStateOf("") }
  var promoMessage by remember { mutableStateOf("") }

  val presetPromos = listOf(
    Pair("🔥 Martes Taquero: 2x1", "Pide hoy 1 orden de Tacos al Pastor y llévate la segunda gratis."),
    Pair("🍚 Combo Arroz Chino Especial", "Arroz Chino Tres Carnes + 2 Lumpias + Bebida con 25% OFF."),
    Pair("🍔 Burger Smash Fest", "Doble smash burger artesanal con papas rústicas y soda por solo $7.99."),
    Pair("🌭 Festival Perro Caliente", "Perro colombiano especial con tocineta y ripio con 2x1.")
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
  ) {
    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier.fillMaxWidth().testTag("admin_broadcast_promo_card")
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.NotificationsActive,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Emitir Notificación Push a Clientes",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Envía una alerta instantánea a la bandeja de notificaciones de Android de tus clientes sobre promociones y ofertas relámpago.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Preset chips
        Text(
          text = "Plantillas Rápidas:",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          presetPromos.forEach { (title, msg) ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surface,
              modifier = Modifier.clickable {
                promoTitle = title
                promoMessage = msg
              }
            ) {
              Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = promoTitle,
          onValueChange = { promoTitle = it },
          label = { Text("Título de la Notificación / Promoción *") },
          placeholder = { Text("Ej: 🔥 ¡Especial de Viernes: 2x1 en Tacos!") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("input_promo_title")
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = promoMessage,
          onValueChange = { promoMessage = it },
          label = { Text("Mensaje de la Alerta *") },
          placeholder = { Text("Describe la promoción o código de descuento...") },
          maxLines = 3,
          modifier = Modifier.fillMaxWidth().testTag("input_promo_message")
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = {
            if (promoTitle.isNotBlank() && promoMessage.isNotBlank()) {
              onBroadcastPromo(promoTitle, promoMessage)
              promoTitle = ""
              promoMessage = ""
            }
          },
          enabled = promoTitle.isNotBlank() && promoMessage.isNotBlank(),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("send_push_notification_button")
        ) {
          Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Enviar Notificación Push Ahora", fontWeight = FontWeight.Bold)
        }
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    Text(
      text = "Historial de Notificaciones Emitidas:",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold
    )
    Spacer(modifier = Modifier.height(8.dp))

    notifications.forEach { notif ->
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = notif.title,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold
            )
            Surface(
              color = MaterialTheme.colorScheme.primaryContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = notif.category.name,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = notif.message,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

// ---------------- 4. ADMIN METRICS VIEW ----------------
@Composable
fun AdminMetricsView(
  orders: List<RestaurantOrder>,
  dishes: List<MenuItem>
) {
  val totalSales = orders.filter { it.status == OrderStatus.ENTREGADO }.sumOf { it.total }
  val activeOrdersCount = orders.count { it.status != OrderStatus.ENTREGADO }
  val completedOrdersCount = orders.count { it.status == OrderStatus.ENTREGADO }
  val avgOrderValue = if (completedOrdersCount > 0) totalSales / completedOrdersCount else 0.0

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
  ) {
    Text(
      text = "Resumen del Negocio",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold
    )
    Spacer(modifier = Modifier.height(12.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      MetricCard(
        title = "Ventas Totales",
        value = String.format(Locale.US, "$%.2f", totalSales),
        icon = "💰",
        modifier = Modifier.weight(1f)
      )
      MetricCard(
        title = "Órdenes Activas",
        value = "$activeOrdersCount",
        icon = "🛵",
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      MetricCard(
        title = "Pedidos Entregados",
        value = "$completedOrdersCount",
        icon = "✅",
        modifier = Modifier.weight(1f)
      )
      MetricCard(
        title = "Ticket Promedio",
        value = String.format(Locale.US, "$%.2f", avgOrderValue),
        icon = "📈",
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(18.dp))

    // Dish distribution
    Card(
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "Distribución del Menú por Categoría:",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(10.dp))

        FoodCategory.entries.filter { it != FoodCategory.TODOS }.forEach { cat ->
          val count = dishes.count { it.category == cat }
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "${cat.iconText} ${cat.displayName}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "$count platos", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun MetricCard(
  title: String,
  value: String,
  icon: String,
  modifier: Modifier = Modifier
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
    shape = RoundedCornerShape(16.dp),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(text = icon, fontSize = 24.sp)
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}
