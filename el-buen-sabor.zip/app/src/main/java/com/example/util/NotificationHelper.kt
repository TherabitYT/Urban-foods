package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.model.OrderStatus

object NotificationHelper {

  const val CHANNEL_ORDERS = "channel_orders_status"
  const val CHANNEL_PROMOS = "channel_promotions"

  private const val NOTIF_ID_ORDER_BASE = 1000
  private const val NOTIF_ID_PROMO_BASE = 2000

  fun createNotificationChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

      // Canal 1: Estado de Pedidos (Alta prioridad con sonido y vibración)
      val ordersChannel = NotificationChannel(
        CHANNEL_ORDERS,
        "Estado de Pedidos (Delivery)",
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = "Alertas en tiempo real sobre la preparación, despacho y entrega de tus pedidos"
        enableVibration(true)
        enableLights(true)
      }

      // Canal 2: Promociones Especiales
      val promosChannel = NotificationChannel(
        CHANNEL_PROMOS,
        "Promociones y Ofertas Especiales",
        NotificationManager.IMPORTANCE_DEFAULT
      ).apply {
        description = "Descuentos exclusivos, combos del día y ofertas de El Buen Sabor"
        enableVibration(true)
      }

      notificationManager.createNotificationChannel(ordersChannel)
      notificationManager.createNotificationChannel(promosChannel)
    }
  }

  fun hasNotificationPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.POST_NOTIFICATIONS
      ) == PackageManager.PERMISSION_GRANTED
    } else {
      true
    }
  }

  fun sendOrderStatusNotification(
    context: Context,
    orderId: String,
    status: OrderStatus,
    driverName: String = "Carlos Mendoza",
    driverPlate: String = "MOTO-782"
  ) {
    if (!hasNotificationPermission(context)) return

    val title: String
    val content: String
    val summaryText: String

    when (status) {
      OrderStatus.CONFIRMADO -> {
        title = "✅ Pedido Recibido • $orderId"
        content = "El Buen Sabor ha confirmado tu orden. Pasará a cocina en breve."
        summaryText = "Confirmado"
      }
      OrderStatus.EN_PREPARACION -> {
        title = "👨‍🍳 ¡En Cocina! • $orderId"
        content = "El chef está preparando tus platos al wok y a la parrilla con los mejores ingredientes."
        summaryText = "En preparación"
      }
      OrderStatus.EN_CAMINO -> {
        title = "🛵 ¡Repartidor en Camino! • $orderId"
        content = "$driverName ($driverPlate) lleva tu comida calientita hacia tu dirección."
        summaryText = "En camino"
      }
      OrderStatus.ENTREGADO -> {
        title = "🎉 ¡Pedido Entregado! • $orderId"
        content = "Tu comida ha sido entregada exitosamente. ¡Que disfrutes de tu comida!"
        summaryText = "Entregado"
      }
    }

    val intent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
      putExtra("order_id", orderId)
    }

    val pendingIntent = PendingIntent.getActivity(
      context,
      orderId.hashCode(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val notification = NotificationCompat.Builder(context, CHANNEL_ORDERS)
      .setSmallIcon(R.drawable.ic_launcher_foreground)
      .setContentTitle(title)
      .setContentText(content)
      .setStyle(NotificationCompat.BigTextStyle().bigText(content).setSummaryText(summaryText))
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setCategory(NotificationCompat.CATEGORY_STATUS)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)
      .build()

    try {
      NotificationManagerCompat.from(context).notify(NOTIF_ID_ORDER_BASE + (orderId.hashCode() % 500), notification)
    } catch (_: SecurityException) {
      // Handled gracefully
    }
  }

  fun sendPromotionNotification(
    context: Context,
    promoTitle: String,
    promoBody: String
  ) {
    if (!hasNotificationPermission(context)) return

    val intent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }

    val pendingIntent = PendingIntent.getActivity(
      context,
      System.currentTimeMillis().toInt(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val notification = NotificationCompat.Builder(context, CHANNEL_PROMOS)
      .setSmallIcon(R.drawable.ic_launcher_foreground)
      .setContentTitle(promoTitle)
      .setContentText(promoBody)
      .setStyle(NotificationCompat.BigTextStyle().bigText(promoBody).setSummaryText("Promoción Especial"))
      .setPriority(NotificationCompat.PRIORITY_DEFAULT)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)
      .build()

    try {
      val notificationId = NOTIF_ID_PROMO_BASE + (System.currentTimeMillis().toInt() % 500)
      NotificationManagerCompat.from(context).notify(notificationId, notification)
    } catch (_: SecurityException) {
      // Handled gracefully
    }
  }
}
