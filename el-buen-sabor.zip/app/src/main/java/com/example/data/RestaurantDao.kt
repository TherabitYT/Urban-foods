package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RestaurantDao {

  @Query("SELECT * FROM orders ORDER BY timestamp DESC")
  fun getAllOrders(): Flow<List<OrderEntity>>

  @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
  fun getOrderById(orderId: String): Flow<OrderEntity?>

  @Query("SELECT * FROM orders WHERE status != 'ENTREGADO' ORDER BY timestamp DESC LIMIT 1")
  fun getLatestActiveOrder(): Flow<OrderEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: OrderEntity)

  @Query("UPDATE orders SET status = :status, estimatedMinutes = :minutesRemaining, driverProgress = :progress WHERE id = :orderId")
  suspend fun updateOrderStatus(orderId: String, status: String, minutesRemaining: Int, progress: Float)

  @Query("SELECT * FROM saved_addresses ORDER BY isDefault DESC, id DESC")
  fun getAllAddresses(): Flow<List<AddressEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAddress(address: AddressEntity): Long

  @Update
  suspend fun updateAddress(address: AddressEntity)

  @Query("DELETE FROM saved_addresses WHERE id = :id")
  suspend fun deleteAddress(id: Long)

  @Query("UPDATE saved_addresses SET isDefault = 0")
  suspend fun clearDefaultAddresses()

  @Query("UPDATE saved_addresses SET isDefault = 1 WHERE id = :id")
  suspend fun setDefaultAddress(id: Long)

  @Query("DELETE FROM orders WHERE id = :orderId")
  suspend fun deleteOrder(orderId: String)

  @Query("SELECT * FROM custom_menu_items")
  fun getAllCustomMenuItems(): Flow<List<CustomMenuItemEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCustomMenuItem(item: CustomMenuItemEntity)

  @Query("UPDATE custom_menu_items SET isAvailable = :isAvailable WHERE id = :id")
  suspend fun updateCustomMenuItemAvailability(id: String, isAvailable: Boolean)

  @Query("DELETE FROM custom_menu_items WHERE id = :id")
  suspend fun deleteCustomMenuItem(id: String)
}
