package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [OrderEntity::class, AddressEntity::class, CustomMenuItemEntity::class],
  version = 3,
  exportSchema = false
)
abstract class RestaurantDatabase : RoomDatabase() {

  abstract fun restaurantDao(): RestaurantDao

  companion object {
    @Volatile
    private var INSTANCE: RestaurantDatabase? = null

    fun getDatabase(context: Context): RestaurantDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          RestaurantDatabase::class.java,
          "el_buen_sabor_database"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
