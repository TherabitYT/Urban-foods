package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.DeliveryAddress
import com.example.model.OrderItemRecord
import com.example.model.OrderStatus
import com.example.model.RestaurantOrder

@Entity(tableName = "orders")
data class OrderEntity(
  @PrimaryKey val id: String,
  val timestamp: Long,
  val status: String,
  val addressLabel: String,
  val addressStreet: String,
  val addressNumber: String,
  val addressNeighborhood: String,
  val addressReference: String,
  val addressPhone: String,
  val addressLatitude: Double = 6.2442,
  val addressLongitude: Double = -75.5812,
  val subtotal: Double,
  val deliveryFee: Double,
  val total: Double,
  val paymentMethod: String,
  val estimatedMinutes: Int,
  val driverName: String,
  val driverPhone: String,
  val driverPlate: String,
  val driverProgress: Float,
  val itemsSummary: String,
  val rawItemsJson: String
) {
  fun toDomain(): RestaurantOrder {
    val itemsList = parseItems(rawItemsJson)
    return RestaurantOrder(
      id = id,
      timestamp = timestamp,
      status = OrderStatus.fromName(status),
      address = DeliveryAddress(
        label = addressLabel,
        street = addressStreet,
        numberOrApartment = addressNumber,
        neighborhood = addressNeighborhood,
        reference = addressReference,
        phone = addressPhone,
        latitude = addressLatitude,
        longitude = addressLongitude
      ),
      items = itemsList,
      subtotal = subtotal,
      deliveryFee = deliveryFee,
      total = total,
      paymentMethod = paymentMethod,
      estimatedMinutesRemaining = estimatedMinutes,
      driverName = driverName,
      driverPhone = driverPhone,
      driverPlate = driverPlate,
      driverRating = 4.9f,
      deliveryProgressPercent = driverProgress
    )
  }

  companion object {
    fun fromDomain(order: RestaurantOrder): OrderEntity {
      val summary = order.items.joinToString(", ") { "${it.quantity}x ${it.menuItemName}" }
      val serialized = serializeItems(order.items)
      return OrderEntity(
        id = order.id,
        timestamp = order.timestamp,
        status = order.status.name,
        addressLabel = order.address.label,
        addressStreet = order.address.street,
        addressNumber = order.address.numberOrApartment,
        addressNeighborhood = order.address.neighborhood,
        addressReference = order.address.reference,
        addressPhone = order.address.phone,
        addressLatitude = order.address.latitude,
        addressLongitude = order.address.longitude,
        subtotal = order.subtotal,
        deliveryFee = order.deliveryFee,
        total = order.total,
        paymentMethod = order.paymentMethod,
        estimatedMinutes = order.estimatedMinutesRemaining,
        driverName = order.driverName,
        driverPhone = order.driverPhone,
        driverPlate = order.driverPlate,
        driverProgress = order.deliveryProgressPercent,
        itemsSummary = summary,
        rawItemsJson = serialized
      )
    }

    // Delimited serialization for reliable storage without external reflection bugs
    private fun serializeItems(items: List<OrderItemRecord>): String {
      return items.joinToString(separator = "||") { item ->
        listOf(
          escape(item.menuItemId),
          escape(item.menuItemName),
          escape(item.categoryName),
          item.unitPrice.toString(),
          item.quantity.toString(),
          escape(item.selectedExtrasSummary),
          escape(item.specialInstructions)
        ).joinToString(separator = "::")
      }
    }

    private fun parseItems(serialized: String): List<OrderItemRecord> {
      if (serialized.isBlank()) return emptyList()
      return serialized.split("||").mapNotNull { chunk ->
        val parts = chunk.split("::")
        if (parts.size >= 7) {
          OrderItemRecord(
            menuItemId = unescape(parts[0]),
            menuItemName = unescape(parts[1]),
            categoryName = unescape(parts[2]),
            unitPrice = parts[3].toDoubleOrNull() ?: 0.0,
            quantity = parts[4].toIntOrNull() ?: 1,
            selectedExtrasSummary = unescape(parts[5]),
            specialInstructions = unescape(parts[6])
          )
        } else null
      }
    }

    private fun escape(s: String): String = s.replace("::", " ").replace("||", " ")
    private fun unescape(s: String): String = s
  }
}

@Entity(tableName = "saved_addresses")
data class AddressEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val label: String,
  val street: String,
  val numberOrApartment: String,
  val neighborhood: String,
  val reference: String,
  val phone: String,
  val isDefault: Boolean,
  val latitude: Double = 6.2442,
  val longitude: Double = -75.5812
) {
  fun toDomain(): DeliveryAddress {
    return DeliveryAddress(
      id = id,
      label = label,
      street = street,
      numberOrApartment = numberOrApartment,
      neighborhood = neighborhood,
      reference = reference,
      phone = phone,
      isDefault = isDefault,
      latitude = latitude,
      longitude = longitude
    )
  }

  companion object {
    fun fromDomain(d: DeliveryAddress): AddressEntity {
      return AddressEntity(
        id = d.id,
        label = d.label,
        street = d.street,
        numberOrApartment = d.numberOrApartment,
        neighborhood = d.neighborhood,
        reference = d.reference,
        phone = d.phone,
        isDefault = d.isDefault,
        latitude = d.latitude,
        longitude = d.longitude
      )
    }
  }
}

@Entity(tableName = "custom_menu_items")
data class CustomMenuItemEntity(
  @PrimaryKey val id: String,
  val name: String,
  val categoryName: String,
  val description: String,
  val price: Double,
  val preparationTime: String,
  val ingredientsCsv: String,
  val badge: String? = null,
  val isAvailable: Boolean = true,
  val customImageUrl: String? = null,
  val imageResName: String = "",
  val customExtrasJson: String = "",
  val customSidesJson: String = "",
  val customSpiceJson: String = ""
)

