package com.example.data

import com.example.model.DeliveryAddress
import com.example.model.OrderItemRecord
import com.example.model.OrderStatus
import com.example.model.RestaurantOrder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class RestaurantRepository(private val dao: RestaurantDao) {

  val allOrders: Flow<List<RestaurantOrder>> = dao.getAllOrders().map { list ->
    list.map { it.toDomain() }
  }

  val activeOrder: Flow<RestaurantOrder?> = dao.getLatestActiveOrder().map { entity ->
    entity?.toDomain()
  }

  val savedAddresses: Flow<List<DeliveryAddress>> = dao.getAllAddresses().map { list ->
    list.map { it.toDomain() }
  }

  suspend fun insertOrder(order: RestaurantOrder) {
    dao.insertOrder(OrderEntity.fromDomain(order))
  }

  suspend fun updateOrderStatus(
    orderId: String,
    status: OrderStatus,
    minutesRemaining: Int,
    progress: Float
  ) {
    dao.updateOrderStatus(orderId, status.name, minutesRemaining, progress)
  }

  suspend fun saveAddress(address: DeliveryAddress) {
    if (address.isDefault) {
      dao.clearDefaultAddresses()
    }
    if (address.id == 0L) {
      dao.insertAddress(AddressEntity.fromDomain(address))
    } else {
      dao.updateAddress(AddressEntity.fromDomain(address))
    }
  }

  suspend fun setDefaultAddress(id: Long) {
    dao.clearDefaultAddresses()
    dao.setDefaultAddress(id)
  }

  suspend fun deleteAddress(id: Long) {
    dao.deleteAddress(id)
  }

  suspend fun deleteOrder(orderId: String) {
    dao.deleteOrder(orderId)
  }

  val customMenuItems: Flow<List<com.example.model.MenuItem>> = dao.getAllCustomMenuItems().map { list ->
    list.map { entity ->
      val cat = com.example.model.FoodCategory.entries.find { it.name == entity.categoryName } ?: com.example.model.FoodCategory.HAMBURGUESAS
      val imgRes = getImageResByName(entity.imageResName, cat)
      val ingredientsList = entity.ingredientsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }

      val extras = parseExtras(entity.customExtrasJson).ifEmpty {
        listOf(
          com.example.model.ExtraOption("ext_queso", "Queso Fundido Extra", 1.25),
          com.example.model.ExtraOption("ext_bacon", "Tocineta Crujiente", 1.50),
          com.example.model.ExtraOption("ext_salsa", "Salsa Especial de la Casa", 0.75)
        )
      }

      val sides = parseSides(entity.customSidesJson).ifEmpty {
        com.example.model.MenuCatalog.standardSides
      }

      val spices = parseSpices(entity.customSpiceJson).ifEmpty {
        com.example.model.MenuCatalog.standardSpiceLevels
      }

      com.example.model.MenuItem(
        id = entity.id,
        name = entity.name,
        category = cat,
        description = entity.description,
        price = entity.price,
        imageRes = imgRes,
        customImageUrl = entity.customImageUrl,
        badge = entity.badge ?: "Especial de la Casa",
        preparationTime = entity.preparationTime.ifBlank { "15-20 min" },
        ingredients = ingredientsList,
        availableExtras = extras,
        availableSides = sides,
        availableSpiceLevels = spices,
        isAvailable = entity.isAvailable
      )
    }
  }

  suspend fun insertCustomMenuItem(item: com.example.model.MenuItem) {
    val imageResName = when (item.imageRes) {
      com.example.R.drawable.img_arroz_chino -> "img_arroz_chino"
      com.example.R.drawable.img_tacos -> "img_tacos"
      com.example.R.drawable.img_hot_dog -> "img_hot_dog"
      com.example.R.drawable.img_burger -> "img_burger"
      com.example.R.drawable.ic_restaurant_logo -> "ic_restaurant_logo"
      else -> "img_burger"
    }

    dao.insertCustomMenuItem(
      CustomMenuItemEntity(
        id = item.id,
        name = item.name,
        categoryName = item.category.name,
        description = item.description,
        price = item.price,
        preparationTime = item.preparationTime,
        ingredientsCsv = item.ingredients.joinToString(", "),
        badge = item.badge,
        isAvailable = item.isAvailable,
        customImageUrl = item.customImageUrl,
        imageResName = imageResName,
        customExtrasJson = serializeExtras(item.availableExtras),
        customSidesJson = serializeSides(item.availableSides),
        customSpiceJson = serializeSpices(item.availableSpiceLevels)
      )
    )
  }

  private fun getImageResByName(name: String, cat: com.example.model.FoodCategory): Int {
    return when (name) {
      "img_arroz_chino" -> com.example.R.drawable.img_arroz_chino
      "img_tacos" -> com.example.R.drawable.img_tacos
      "img_hot_dog" -> com.example.R.drawable.img_hot_dog
      "img_burger" -> com.example.R.drawable.img_burger
      "ic_restaurant_logo" -> com.example.R.drawable.ic_restaurant_logo
      else -> when (cat) {
        com.example.model.FoodCategory.ARROZ_CHINO -> com.example.R.drawable.img_arroz_chino
        com.example.model.FoodCategory.TACOS -> com.example.R.drawable.img_tacos
        com.example.model.FoodCategory.HOT_DOGS -> com.example.R.drawable.img_hot_dog
        com.example.model.FoodCategory.HAMBURGUESAS -> com.example.R.drawable.img_burger
        else -> com.example.R.drawable.img_burger
      }
    }
  }

  private fun serializeExtras(extras: List<com.example.model.ExtraOption>): String =
    extras.joinToString(";;") { "${it.id}::${it.name}::${it.price}" }

  private fun parseExtras(str: String): List<com.example.model.ExtraOption> {
    if (str.isBlank()) return emptyList()
    return str.split(";;").mapNotNull { chunk ->
      val parts = chunk.split("::")
      if (parts.size >= 3) {
        com.example.model.ExtraOption(parts[0], parts[1], parts[2].toDoubleOrNull() ?: 0.0)
      } else null
    }
  }

  private fun serializeSides(sides: List<com.example.model.SideOption>): String =
    sides.joinToString(";;") { "${it.id}::${it.name}::${it.price}" }

  private fun parseSides(str: String): List<com.example.model.SideOption> {
    if (str.isBlank()) return emptyList()
    return str.split(";;").mapNotNull { chunk ->
      val parts = chunk.split("::")
      if (parts.size >= 3) {
        com.example.model.SideOption(parts[0], parts[1], parts[2].toDoubleOrNull() ?: 0.0)
      } else null
    }
  }

  private fun serializeSpices(spices: List<com.example.model.SpiceLevel>): String =
    spices.joinToString(";;") { "${it.id}::${it.name}::${it.description}::${it.price}::${it.icon}" }

  private fun parseSpices(str: String): List<com.example.model.SpiceLevel> {
    if (str.isBlank()) return emptyList()
    return str.split(";;").mapNotNull { chunk ->
      val parts = chunk.split("::")
      if (parts.size >= 5) {
        com.example.model.SpiceLevel(parts[0], parts[1], parts[2], parts[3].toDoubleOrNull() ?: 0.0, parts[4])
      } else null
    }
  }

  suspend fun updateCustomMenuItemAvailability(id: String, isAvailable: Boolean) {
    dao.updateCustomMenuItemAvailability(id, isAvailable)
  }

  suspend fun deleteCustomMenuItem(id: String) {
    dao.deleteCustomMenuItem(id)
  }


  fun initializeSeedDataIfEmpty(scope: CoroutineScope) {
    scope.launch(Dispatchers.IO) {
      val existingAddresses = dao.getAllAddresses().first()
      if (existingAddresses.isEmpty()) {
        val defaultAddress = DeliveryAddress(
          id = 0,
          label = "Casa",
          street = "Calle 45 # 18-32",
          numberOrApartment = "Apto 302",
          neighborhood = "La Floresta",
          reference = "Edificio blanco con portón verde, timbre 302",
          phone = "+57 301 555 7890",
          isDefault = true
        )
        val workAddress = DeliveryAddress(
          id = 0,
          label = "Trabajo",
          street = "Carrera 7 # 72-10",
          numberOrApartment = "Oficina 504",
          neighborhood = "Centro Financiero",
          reference = "Recepción Torre Norte",
          phone = "+57 301 555 7890",
          isDefault = false
        )
        dao.insertAddress(AddressEntity.fromDomain(defaultAddress))
        dao.insertAddress(AddressEntity.fromDomain(workAddress))
      }

      val existingOrders = dao.getAllOrders().first()
      if (existingOrders.isEmpty()) {
        // Seed an authentic previous order so user can immediately test "Historial de compras" and "Pedir de nuevo"
        val pastOrder1 = RestaurantOrder(
          id = "ORD-4821",
          timestamp = System.currentTimeMillis() - (86400000L * 2), // 2 days ago
          status = OrderStatus.ENTREGADO,
          address = DeliveryAddress(
            label = "Casa",
            street = "Calle 45 # 18-32",
            numberOrApartment = "Apto 302",
            neighborhood = "La Floresta",
            reference = "Edificio blanco con portón verde",
            phone = "+57 301 555 7890"
          ),
          items = listOf(
            OrderItemRecord(
              menuItemId = "ac_1",
              menuItemName = "Arroz Chino Especial Tres Carnes",
              categoryName = "Arroz Chino",
              unitPrice = 8.50,
              quantity = 1,
              selectedExtrasSummary = "Extra Camarones Jumbo (4 uds)",
              specialInstructions = "Salsa agridulce aparte por favor"
            ),
            OrderItemRecord(
              menuItemId = "tc_1",
              menuItemName = "Tacos al Pastor con Piña Asada",
              categoryName = "Tacos",
              unitPrice = 6.75,
              quantity = 2,
              selectedExtrasSummary = "Guacamole Cremoso",
              specialInstructions = ""
            )
          ),
          subtotal = 22.00,
          deliveryFee = 2.50,
          total = 24.50,
          paymentMethod = "Tarjeta Débito/Crédito",
          estimatedMinutesRemaining = 0,
          driverName = "Carlos Mendoza",
          driverPhone = "+57 312 884 9201",
          driverPlate = "MOTO-782",
          deliveryProgressPercent = 1.0f
        )

        val pastOrder2 = RestaurantOrder(
          id = "ORD-3914",
          timestamp = System.currentTimeMillis() - (86400000L * 5), // 5 days ago
          status = OrderStatus.ENTREGADO,
          address = DeliveryAddress(
            label = "Casa",
            street = "Calle 45 # 18-32",
            numberOrApartment = "Apto 302",
            neighborhood = "La Floresta",
            reference = "Edificio blanco con portón verde",
            phone = "+57 301 555 7890"
          ),
          items = listOf(
            OrderItemRecord(
              menuItemId = "bg_1",
              menuItemName = "Smash Burger Doble Carne & Tocino",
              categoryName = "Hamburguesas",
              unitPrice = 8.95,
              quantity = 1,
              selectedExtrasSummary = "Doble Tocineta Ahumada",
              specialInstructions = "Sin cebolla"
            ),
            OrderItemRecord(
              menuItemId = "hd_1",
              menuItemName = "Perro Caliente Especial Colombiano",
              categoryName = "Perros Calientes",
              unitPrice = 5.50,
              quantity = 1,
              selectedExtrasSummary = "Baño de Queso Cheddar Fundido",
              specialInstructions = "Bastante tártara"
            )
          ),
          subtotal = 14.45,
          deliveryFee = 2.50,
          total = 16.95,
          paymentMethod = "Efectivo",
          estimatedMinutesRemaining = 0,
          driverName = "Andrés Gómez",
          driverPhone = "+57 310 442 1982",
          driverPlate = "MOTO-193",
          deliveryProgressPercent = 1.0f
        )

        dao.insertOrder(OrderEntity.fromDomain(pastOrder1))
        dao.insertOrder(OrderEntity.fromDomain(pastOrder2))
      }
    }
  }
}
